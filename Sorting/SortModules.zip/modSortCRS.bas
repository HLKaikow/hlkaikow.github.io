Attribute VB_Name = "modSortCRS"
' Copyright � 2003-2004 by Howard Kaikow. All rights reserved.
' Author URL: http://www.standards.com/
' Author email address: kaikow@standards.com
' Date: 13 February 2004

' In this class, each algorithm, call it XXX, is implemented using 5 variations: XXXLong, XXXDouble, XXXString,
' pXXXDouble and pXXXString, where the pXXX use pointers, instead of a direct manipulation of the data.

' The KeyIndexed and HKKeyIndexed algorithms do not have pointer variations.
    
' The algorithms in this class are based on the algorithm descriptions in "Algorithms in C, Third Edition,"
' by Robert Sedgewick, Addison-Wesley, 1998, and include modifications of those algorithms.

' The GetMedian and Med3 functions are based on:
    ' Jon L. Bentley and M. Douglas McIlroy, Engineering a Sort Function,
    ' Software-Practice and Experience, vol. 23(11), 1249-1265 (November 1993)
Option Explicit
Private Const MergeCutoff As Long = 10
Private Const QuickCutoff As Long = 10
Private Const M1 As Long = QuickCutoff + 1

Public Sub QuickLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1
    Dim i As Long
    If r > L Then
        i = PartitionLong(a(), L, r)
        Call QuickLong(a(), L, i - 1)
        Call QuickLong(a(), i + 1, r)
    End If
End Sub

Public Sub QuickDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1
    Dim i As Long
    If r > L Then
        i = PartitionDouble(a(), L, r)
        Call QuickDouble(a(), L, i - 1)
        Call QuickDouble(a(), i + 1, r)
    End If
End Sub

Public Sub QuickString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1
    Dim i As Long
    If r > L Then
        i = PartitionString(a(), L, r)
        Call QuickString(a(), L, i - 1)
        Call QuickString(a(), i + 1, r)
    End If
End Sub

Public Sub pQuickDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified to use pointers
    Dim i As Long
    If r > L Then
        i = pPartitionDouble(a(), Ptr(), L, r)
        Call pQuickDouble(a(), Ptr(), L, i - 1)
        Call pQuickDouble(a(), Ptr(), i + 1, r)
    End If
End Sub

Public Sub pQuickString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified to use pointers
    Dim i As Long
    If r > L Then
        i = pPartitionString(a(), Ptr(), L, r)
        Call pQuickString(a(), Ptr(), L, i - 1)
        Call pQuickString(a(), Ptr(), i + 1, r)
    End If
End Sub

Public Sub QuickInLineLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim v As Long
    Dim temp As Long
    
    If r > L Then
    '            i = PartitionLong(a(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(r)
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        Call QuickInLineLong(a(), L, i - 1)
        Call QuickInLineLong(a(), i + 1, r)
    End If
End Sub

Public Sub QuickInLineDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim v As Double
    Dim temp As Double
    
    If r > L Then
    '            i = PartitionDouble(a(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(r)
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        Call QuickInLineDouble(a(), L, i - 1)
        Call QuickInLineDouble(a(), i + 1, r)
    End If
End Sub

Public Sub QuickInLineString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim v As String
    Dim temp As String
    
    If r > L Then
    '            i = PartitionString(a(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(r)
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        Call QuickInLineString(a(), L, i - 1)
        Call QuickInLineString(a(), i + 1, r)
    End If
End Sub

Public Sub pQuickInLineDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, includes 7.2, uses pointers
    Dim i As Long
    Dim j As Long
    Dim v As Double
    Dim temp As Long
    
    If r > L Then
    '            i = pPartitionDouble(a(), ptr(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(Ptr(r))
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        Call pQuickInLineDouble(a(), Ptr(), L, i - 1)
        Call pQuickInLineDouble(a(), Ptr(), i + 1, r)
    End If
End Sub

Public Sub pQuickInLineString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, includes 7.2, uses pointers
    Dim i As Long
    Dim j As Long
    Dim v As String
    Dim temp As Long
    
    If r > L Then
    '            i = pPartitionString(a(), ptr(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(Ptr(r))
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        Call pQuickInLineString(a(), Ptr(), L, i - 1)
        Call pQuickInLineString(a(), Ptr(), i + 1, r)
    End If
End Sub

Public Sub QuickModLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified
    Dim i As Long
    
    Do While r > L
        i = PartitionLong(a(), L, r)
        If i - L < r - i Then
            Call QuickModLong(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickModLong(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickModDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified
    Dim i As Long
    
    Do While r > L
        i = PartitionDouble(a(), L, r)
        If i - L < r - i Then
            Call QuickModDouble(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickModDouble(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickModString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified
    Dim i As Long
    
    Do While r > L
        i = PartitionString(a(), L, r)
        If i - L < r - i Then
            Call QuickModString(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickModString(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub pQuickModDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified and uses pointers
    Dim i As Long
    
    Do While r > L
        i = pPartitionDouble(a(), Ptr(), L, r)
        If i - L < r - i Then
            Call pQuickModDouble(a(), Ptr(), L, i - 1)
            L = i + 1
        Else
            Call pQuickModDouble(a(), Ptr(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub pQuickModString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified and uses pointers
    Dim i As Long
    
    Do While r > L
        i = pPartitionString(a(), Ptr(), L, r)
        If i - L < r - i Then
            Call pQuickModString(a(), Ptr(), L, i - 1)
            L = i + 1
        Else
            Call pQuickModString(a(), Ptr(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickModInLineLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim v As Long
    Dim temp As Long
    
    Do While r > L
    '            i = PartitionLong(a(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(r)
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call QuickModInLineLong(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickModInLineLong(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickModInLineDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim v As Double
    Dim temp As Double
    
    Do While r > L
    '            i = PartitionDouble(a(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(r)
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call QuickModInLineDouble(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickModInLineDouble(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickModInLineString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim v As String
    Dim temp As String
    
    Do While r > L
    '            i = PartitionString(a(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(r)
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call QuickModInLineString(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickModInLineString(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub pQuickModInLineDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified, includes 7.2, uses pointers
    Dim i As Long
    Dim j As Long
    Dim v As Double
    Dim temp As Long
    
    Do While r > L
    '            i = pPartitionDouble(a(), ptr(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(Ptr(r))
        i = L - 1
        j = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call pQuickModInLineDouble(a(), Ptr(), L, i - 1)
            L = i + 1
        Else
            Call pQuickModInLineDouble(a(), Ptr(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub pQuickModInLineString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.1, modified, includes 7.2, uses pointers
    Dim i As Long
    Dim j As Long
    Dim v As String
    Dim temp As Long
    
    Do While r > L
    '            i = pPartitionString(a(), ptr(), L, r)
        '''''''''''''''''''''''''''''''''''''''
        v = a(Ptr(r))
        i = L - 1
        j = r
        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call pQuickModInLineString(a(), Ptr(), L, i - 1)
            L = i + 1
        Else
            Call pQuickModInLineString(a(), Ptr(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Private Function PartitionLong(a() As Long, ByVal L As Long, ByVal r As Long) As Long
    ' Sedgewick 7.2
    Dim i As Long
    Dim j As Long
    Dim v As Long
    Dim temp As Long
        
    v = a(r)
    i = L - 1
    j = r
    Do
        Do
            i = i + 1
        Loop While a(i) < v
        Do
            If j = L Then
                Exit Do
            End If
            j = j - 1
        Loop While v < a(j)
        If i >= j Then
            Exit Do
        End If
        temp = a(i)
        a(i) = a(j)
        a(j) = temp
    Loop
    temp = a(i)
    a(i) = a(r)
    a(r) = temp
    PartitionLong = i
End Function

Private Function PartitionDouble(a() As Double, ByVal L As Long, ByVal r As Long) As Long
    ' Sedgewick 7.2
    Dim i As Long
    Dim j As Long
    Dim v As Double
    Dim temp As Double
        
    v = a(r)
    i = L - 1
    j = r
    Do
        Do
            i = i + 1
        Loop While a(i) < v
        Do
            If j = L Then

                Exit Do
            End If
            j = j - 1
        Loop While v < a(j)
        If i >= j Then
            Exit Do
        End If
        temp = a(i)
        a(i) = a(j)
        a(j) = temp
    Loop
    temp = a(i)
    a(i) = a(r)
    a(r) = temp
    PartitionDouble = i
End Function

Private Function PartitionString(a() As String, ByVal L As Long, ByVal r As Long) As Long
    ' Sedgewick 7.2
    Dim i As Long
    Dim j As Long
    Dim v As String
    Dim temp As String
        
    v = a(r)
    i = L - 1
    j = r
    Do
        Do
            i = i + 1
        Loop While a(i) < v
        Do
            If j = L Then

                Exit Do
            End If
            j = j - 1
        Loop While v < a(j)
        If i >= j Then
            Exit Do
        End If
        temp = a(i)
        a(i) = a(j)
        a(j) = temp
    Loop
    temp = a(i)
    a(i) = a(r)
    a(r) = temp
    PartitionString = i
End Function

Private Function pPartitionDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long) As Long
    ' Sedgewick 7.2, modified to use pointers
    Dim i As Long
    Dim j As Long
    Dim v As Double
    Dim temp As Long
        
    v = a(Ptr(r))
    i = L - 1
    j = r
    Do
        Do
            i = i + 1
        Loop While a(Ptr(i)) < v
        Do
            If j = L Then

                Exit Do
            End If
            j = j - 1
        Loop While v < a(Ptr(j))
        If i >= j Then
            Exit Do
        End If
        temp = Ptr(i)
        Ptr(i) = Ptr(j)
        Ptr(j) = temp
    Loop
    temp = Ptr(i)
    Ptr(i) = Ptr(r)
    Ptr(r) = temp
    pPartitionDouble = i
End Function

Private Function pPartitionString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long) As Long
    ' Sedgewick 7.2, modified to use pointers
    Dim i As Long
    Dim j As Long
    Dim v As String
    Dim temp As Long
        
    v = a(Ptr(r))
    i = L - 1
    j = r
    Do
        Do
            i = i + 1
        Loop While a(Ptr(i)) < v
        Do
            If j = L Then

                Exit Do
            End If
            j = j - 1
        Loop While v < a(Ptr(j))
        If i >= j Then
            Exit Do
        End If
        temp = Ptr(i)
        Ptr(i) = Ptr(j)
        Ptr(j) = temp
    Loop
    temp = Ptr(i)
    Ptr(i) = Ptr(r)
    Ptr(r) = temp
    pPartitionString = i
End Function

Public Sub QuickImprovedMainLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4
    Call QuickImprovedLong(a(), L, r)
    Call InsertionLong(a(), L, r)
End Sub

Public Sub QuickImprovedLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
        i = PartitionLong(a(), L + 1, r - 1)
    
        Call QuickImprovedLong(a(), L, i - 1)
        Call QuickImprovedLong(a(), i + 1, r)
    End If
End Sub

Public Sub QuickImprovedMainDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4
    Call QuickImprovedDouble(a(), L, r)
    Call InsertionDouble(a(), L, r)
End Sub

Public Sub QuickImprovedDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Double
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
        i = PartitionDouble(a(), L + 1, r - 1)
    
        Call QuickImprovedDouble(a(), L, i - 1)
        Call QuickImprovedDouble(a(), i + 1, r)
    End If
End Sub

Public Sub QuickImprovedMainString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4
    Call QuickImprovedString(a(), L, r)
    Call InsertionString(a(), L, r)
End Sub

Public Sub QuickImprovedString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As String
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
        i = PartitionString(a(), L + 1, r - 1)
    
        Call QuickImprovedString(a(), L, i - 1)
        Call QuickImprovedString(a(), i + 1, r)
    End If
End Sub

Public Sub pQuickImprovedMainDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Call pQuickImprovedDouble(a(), Ptr(), L, r)
    Call pInsertionDouble(a(), Ptr(), L, r)
End Sub

Public Sub pQuickImprovedDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        temp = Ptr(mid)
        Ptr(mid) = Ptr(pp)
        Ptr(pp) = temp
        
        If a(Ptr(L)) > a(Ptr(pp)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(pp)
            Ptr(pp) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(pp)) > a(Ptr(r)) Then
            temp = Ptr(pp)
            Ptr(pp) = Ptr(r)
            Ptr(r) = temp
        End If
        
        i = pPartitionDouble(a(), Ptr(), L + 1, r - 1)
    
        Call pQuickImprovedDouble(a(), Ptr(), L, i - 1)
        Call pQuickImprovedDouble(a(), Ptr(), i + 1, r)
    End If
End Sub

Public Sub pQuickImprovedMainString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Call pQuickImprovedString(a(), Ptr(), L, r)
    Call pInsertionString(a(), Ptr(), L, r)
End Sub

Public Sub pQuickImprovedString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    
    If r - L > QuickCutoff Then
        temp = Ptr(mid)
        Ptr(mid) = Ptr(pp)
        Ptr(pp) = temp
        
        If a(Ptr(L)) > a(Ptr(pp)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(pp)
            Ptr(pp) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(pp)) > a(Ptr(r)) Then
            temp = Ptr(pp)
            Ptr(pp) = Ptr(r)
            Ptr(r) = temp
        End If
        
        i = pPartitionString(a(), Ptr(), L + 1, r - 1)
    
        Call pQuickImprovedString(a(), Ptr(), L, i - 1)
        Call pQuickImprovedString(a(), Ptr(), i + 1, r)
    End If
End Sub

Public Sub QuickImprovedInlineMainLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Call QuickImprovedInlineLong(a(), L, r)
    Call InsertionLong(a(), L, r)
End Sub

Public Sub QuickImprovedInlineLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    Dim v As Long
    Dim temp As Long
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
    '            i = PartitionLong(a(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(rPart)
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = lPart Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(rPart)
        a(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''
        Call QuickImprovedInlineLong(a(), L, i - 1)
        Call QuickImprovedInlineLong(a(), i + 1, r)
    End If
End Sub

Public Sub QuickImprovedInlineMainDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Call QuickImprovedInlineDouble(a(), L, r)
    Call InsertionDouble(a(), L, r)
End Sub

Public Sub QuickImprovedInlineDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, inludes 7.2
    Dim v As Double
    Dim temp As Double
    Dim i As Long

    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
    '            i = PartitionDouble(a(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(rPart)
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = lPart Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(rPart)
        a(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''
        Call QuickImprovedInlineDouble(a(), L, i - 1)
        Call QuickImprovedInlineDouble(a(), i + 1, r)
    End If
End Sub

Public Sub QuickImprovedInlineMainString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Call QuickImprovedInlineString(a(), L, r)
    Call InsertionString(a(), L, r)
End Sub

Public Sub QuickImprovedInlineString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    Dim v As String
    Dim temp As String
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
    '            i = PartitionString(a(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(rPart)
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = lPart Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(rPart)
        a(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''
        Call QuickImprovedInlineString(a(), L, i - 1)
        Call QuickImprovedInlineString(a(), i + 1, r)
    End If
End Sub

Public Sub pQuickImprovedInlineMainDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Call pQuickImprovedInlineDouble(a(), Ptr(), L, r)
    Call pInsertionDouble(a(), Ptr(), L, r)
End Sub

Public Sub pQuickImprovedInlineDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Dim i As Long
    Dim j As Long
    Dim lPart As Long
    Dim rPart As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    Dim v As Double
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = Ptr(mid)
        Ptr(mid) = Ptr(pp)
        Ptr(pp) = temp
        
        If a(Ptr(L)) > a(Ptr(pp)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(pp)
            Ptr(pp) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(pp)) > a(Ptr(r)) Then
            temp = Ptr(pp)
            Ptr(pp) = Ptr(r)
            Ptr(r) = temp
        End If
        
    '            i = pPartitionDouble(a(), ptr(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(Ptr(rPart))
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = lPart Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(rPart)
        Ptr(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''

        Call pQuickImprovedInlineDouble(a(), Ptr(), L, i - 1)
        Call pQuickImprovedInlineDouble(a(), Ptr(), i + 1, r)
    End If
End Sub

Public Sub pQuickImprovedInlineMainString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Call pQuickImprovedInlineString(a(), Ptr(), L, r)
    Call pInsertionString(a(), Ptr(), L, r)
End Sub

Public Sub pQuickImprovedInlineString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Dim i As Long
    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    Dim v As String
    
    If r - L > QuickCutoff Then
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = Ptr(mid)
        Ptr(mid) = Ptr(pp)
        Ptr(pp) = temp
        
        If a(Ptr(L)) > a(Ptr(pp)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(pp)
            Ptr(pp) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(pp)) > a(Ptr(r)) Then
            temp = Ptr(pp)
            Ptr(pp) = Ptr(r)
            Ptr(r) = temp
        End If
        
    '            i = pPartitionString(a(), ptr(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(Ptr(rPart))
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = lPart Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(rPart)
        Ptr(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''

        Call pQuickImprovedInlineString(a(), Ptr(), L, i - 1)
        Call pQuickImprovedInlineString(a(), Ptr(), i + 1, r)
    End If
End Sub

Public Sub QuickImprovedModMainLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Call QuickImprovedLong(a(), L, r)
    Call InsertionLong(a(), L, r)
End Sub

Public Sub QuickImprovedModLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
        i = PartitionLong(a(), L + 1, r - 1)

        If i - L < r - i Then
            Call QuickImprovedModLong(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickImprovedModLong(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickImprovedModMainDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Call QuickImprovedDouble(a(), L, r)
    Call InsertionDouble(a(), L, r)
End Sub

Public Sub QuickImprovedModDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Double
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
        i = PartitionDouble(a(), L + 1, r - 1)

        If i - L < r - i Then
            Call QuickImprovedModDouble(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickImprovedModDouble(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickImprovedModMainString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Call QuickImprovedString(a(), L, r)
    Call InsertionString(a(), L, r)
End Sub

Public Sub QuickImprovedModString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As String
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
        i = PartitionString(a(), L + 1, r - 1)

        If i - L < r - i Then
            Call QuickImprovedModString(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickImprovedModString(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub pQuickImprovedModMainDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Call pQuickImprovedDouble(a(), Ptr(), L, r)
    Call pInsertionDouble(a(), Ptr(), L, r)
End Sub

Public Sub pQuickImprovedModDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = Ptr(mid)
        Ptr(mid) = Ptr(pp)
        Ptr(pp) = temp
        
        If a(Ptr(L)) > a(Ptr(pp)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(pp)
            Ptr(pp) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(pp)) > a(Ptr(r)) Then
            temp = Ptr(pp)
            Ptr(pp) = Ptr(r)
            Ptr(r) = temp
        End If
        
        i = pPartitionDouble(a(), Ptr(), L + 1, r - 1)

        If i - L < r - i Then
            Call pQuickImprovedModDouble(a(), Ptr(), L, i - 1)
            L = i + 1
        Else
            Call pQuickImprovedModDouble(a(), Ptr(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub pQuickImprovedModMainString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Call pQuickImprovedString(a(), Ptr(), L, r)
    Call pInsertionString(a(), Ptr(), L, r)
End Sub

Public Sub pQuickImprovedModString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Dim i As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = Ptr(mid)
        Ptr(mid) = Ptr(pp)
        Ptr(pp) = temp
        
        If a(Ptr(L)) > a(Ptr(pp)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(pp)
            Ptr(pp) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(pp)) > a(Ptr(r)) Then
            temp = Ptr(pp)
            Ptr(pp) = Ptr(r)
            Ptr(r) = temp
        End If
        
        i = pPartitionString(a(), Ptr(), L + 1, r - 1)

        If i - L < r - i Then
            Call pQuickImprovedModString(a(), Ptr(), L, i - 1)
            L = i + 1
        Else
            Call pQuickImprovedModString(a(), Ptr(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickImprovedModInlineMainLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Call QuickImprovedLong(a(), L, r)
    Call InsertionLong(a(), L, r)
End Sub

Public Sub QuickImprovedModInlineLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    Dim v As Long
    Dim temp As Long
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
'            i = PartitionLong(a(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(rPart)
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = lPart Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(rPart)
        a(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call QuickImprovedModInlineLong(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickImprovedModInlineLong(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickImprovedModInlineMainDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Call QuickImprovedDouble(a(), L, r)
    Call InsertionDouble(a(), L, r)
End Sub

Public Sub QuickImprovedModInlineDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, inludes 7.2
    Dim v As Double
    Dim temp As Double
    Dim i As Long
    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
'            i = PartitionDouble(a(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(rPart)
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = lPart Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(rPart)
        a(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call QuickImprovedModInlineDouble(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickImprovedModInlineDouble(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub QuickImprovedModInlineMainString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified
    Call QuickImprovedString(a(), L, r)
    Call InsertionString(a(), L, r)
End Sub

Public Sub QuickImprovedModInlineString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, includes 7.2
    Dim i As Long
    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    Dim v As String
    Dim temp As String
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = a(mid)
        a(mid) = a(pp)
        a(pp) = temp
        
        If a(L) > a(pp) Then
            temp = a(L)
            a(L) = a(pp)
            a(pp) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(pp) > a(r) Then
            temp = a(pp)
            a(pp) = a(r)
            a(r) = temp
        End If
        
'            i = PartitionString(a(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(rPart)
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = lPart Then
                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(rPart)
        a(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call QuickImprovedModInlineString(a(), L, i - 1)
            L = i + 1
        Else
            Call QuickImprovedModInlineString(a(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub pQuickImprovedModInlineMainDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Call pQuickImprovedDouble(a(), Ptr(), L, r)
    Call pInsertionDouble(a(), Ptr(), L, r)
End Sub

Public Sub pQuickImprovedModInlineDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Dim i As Long
    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    Dim v As Double
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = Ptr(mid)
        Ptr(mid) = Ptr(pp)
        Ptr(pp) = temp
        
        If a(Ptr(L)) > a(Ptr(pp)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(pp)
            Ptr(pp) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(pp)) > a(Ptr(r)) Then
            temp = Ptr(pp)
            Ptr(pp) = Ptr(r)
            Ptr(r) = temp
        End If
        
'            i = pPartitionDouble(a(), ptr(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(rPart)
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = lPart Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(rPart)
        a(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''

        If i - L < r - i Then
            Call pQuickImprovedModInlineDouble(a(), Ptr(), L, i - 1)
            L = i + 1
        Else
            Call pQuickImprovedModInlineDouble(a(), Ptr(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub pQuickImprovedModInlineMainString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Call pQuickImprovedString(a(), Ptr(), L, r)
    Call pInsertionString(a(), Ptr(), L, r)
End Sub

Public Sub pQuickImprovedModInlineString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.4, modified, with pointers
    Dim i As Long
    Dim j As Long
    Dim rPart As Long
    Dim lPart As Long
    Dim mid As Long
    Dim pp As Long
    Dim temp As Long
    Dim v As String
    
    Do While r - L > M1
        pp = r - 1
        mid = (L + r) \ 2
        
        temp = Ptr(mid)
        Ptr(mid) = Ptr(pp)
        Ptr(pp) = temp
        
        If a(Ptr(L)) > a(Ptr(pp)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(pp)
            Ptr(pp) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(pp)) > a(Ptr(r)) Then
            temp = Ptr(pp)
            Ptr(pp) = Ptr(r)
            Ptr(r) = temp
        End If
        
'            i = pPartitionString(a(), ptr(), L + 1, r - 1)
        '''''''''''''''''''''''''''''''''''''''''''''''
        lPart = L + 1
        rPart = r - 1
        v = a(rPart)
        i = lPart - 1
        j = rPart

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = lPart Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
        Loop
        temp = a(i)
        a(i) = a(rPart)
        a(rPart) = temp
        '''''''''''''''''''''''''''''''''''''''
        If i - L < r - i Then
            Call pQuickImprovedModInlineString(a(), Ptr(), L, i - 1)
            L = i + 1
        Else
            Call pQuickImprovedModInlineString(a(), Ptr(), i + 1, r)
            r = i - 1
        End If
    Loop
End Sub

Public Sub Quick3WayLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Long
    Dim temp As Long
    
    If r > L Then
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        Call Quick3WayLong(a(), L, j)
        Call Quick3WayLong(a(), i, r)
    End If
End Sub

Public Sub Quick3WayDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Double
    
    If r > L Then
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        Call Quick3WayDouble(a(), L, j)
        Call Quick3WayDouble(a(), i, r)
    End If
End Sub

Public Sub Quick3WayString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As String
    
    If r > L Then
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        Call Quick3WayString(a(), L, j)
        Call Quick3WayString(a(), i, r)
    End If
End Sub

Public Sub pQuick3WayDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Long
    
    If r > L Then
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        Call pQuick3WayDouble(a(), Ptr(), L, j)
        Call pQuick3WayDouble(a(), Ptr(), i, r)
    End If
End Sub

Public Sub pQuick3WayString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As Long
    
    If r > L Then
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))
            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        Call pQuick3WayString(a(), Ptr(), L, j)
        Call pQuick3WayString(a(), Ptr(), i, r)
    End If
End Sub

Public Sub Quick3WayModLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Long
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call InsertionLong(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        i = r - 1
        k = (L + r) \ 2
        temp = a(k)
        a(k) = a(i)
        a(i) = temp
        
        If a(L) > a(i) Then
            temp = a(L)
            a(L) = a(i)
            a(i) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(i) > a(r) Then
            temp = a(i)
            a(i) = a(r)
            a(r) = temp
        End If
        
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModLong(a(), L, j)
            Call Quick3WayModLong(a(), i, r)
        Else
            Call Quick3WayModLong(a(), i, r)
            Call Quick3WayModLong(a(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Double
    
    If r - L <= QuickCutoff Then
        Call InsertionDouble(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        i = r - 1
        k = (L + r) \ 2
        temp = a(k)
        a(k) = a(i)
        a(i) = temp
        
        If a(L) > a(i) Then
            temp = a(L)
            a(L) = a(i)
            a(i) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(i) > a(r) Then
            temp = a(i)
            a(i) = a(r)
            a(r) = temp
        End If
        
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModDouble(a(), L, j)
            Call Quick3WayModDouble(a(), i, r)
        Else
            Call Quick3WayModDouble(a(), i, r)
            Call Quick3WayModDouble(a(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As String
    
    If r - L <= QuickCutoff Then
        Call InsertionString(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        i = r - 1
        k = (L + r) \ 2
        temp = a(k)
        a(k) = a(i)
        a(i) = temp
        
        If a(L) > a(i) Then
            temp = a(L)
            a(L) = a(i)
            a(i) = temp
        End If
        
        If a(L) > a(r) Then
            temp = a(L)
            a(L) = a(r)
            a(r) = temp
        End If
        
        If a(i) > a(r) Then
            temp = a(i)
            a(i) = a(r)
            a(r) = temp
        End If
        
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModString(a(), L, j)
            Call Quick3WayModString(a(), i, r)
        Else
            Call Quick3WayModString(a(), i, r)
            Call Quick3WayModString(a(), L, j)
        End If
    End If
End Sub

Public Sub pQuick3WayModDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call pInsertionDouble(a(), Ptr(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        i = r - 1
        k = (L + r) \ 2
        temp = Ptr(k)
        Ptr(k) = Ptr(i)
        Ptr(i) = temp
        
        If a(Ptr(L)) > a(Ptr(i)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(i)
            Ptr(i) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(i)) > a(Ptr(r)) Then
            temp = Ptr(i)
            Ptr(i) = Ptr(r)
            Ptr(r) = temp
        End If
        
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call pQuick3WayModDouble(a(), Ptr(), L, j)
            Call pQuick3WayModDouble(a(), Ptr(), i, r)
        Else
            Call pQuick3WayModDouble(a(), Ptr(), i, r)
            Call pQuick3WayModDouble(a(), Ptr(), L, j)
        End If
    End If
End Sub

Public Sub pQuick3WayModString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call pInsertionString(a(), Ptr(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        i = r - 1
        k = (L + r) \ 2
        temp = Ptr(k)
        Ptr(k) = Ptr(i)
        Ptr(i) = temp
        
        If a(Ptr(L)) > a(Ptr(i)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(i)
            Ptr(i) = temp
        End If
        
        If a(Ptr(L)) > a(Ptr(r)) Then
            temp = Ptr(L)
            Ptr(L) = Ptr(r)
            Ptr(r) = temp
        End If
        
        If a(Ptr(i)) > a(Ptr(r)) Then
            temp = Ptr(i)
            Ptr(i) = Ptr(r)
            Ptr(r) = temp
        End If
        
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call pQuick3WayModString(a(), Ptr(), L, j)
            Call pQuick3WayModString(a(), Ptr(), i, r)
        Else
            Call pQuick3WayModString(a(), Ptr(), i, r)
            Call pQuick3WayModString(a(), Ptr(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedianLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Long
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call InsertionLong(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = (L + r) \ 2
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedianLong(a(), L, j)
            Call Quick3WayModMedianLong(a(), i, r)
        Else
            Call Quick3WayModMedianLong(a(), i, r)
            Call Quick3WayModMedianLong(a(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedianDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Double
    
    If r - L <= QuickCutoff Then
        Call InsertionDouble(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = (L + r) \ 2
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedianDouble(a(), L, j)
            Call Quick3WayModMedianDouble(a(), i, r)
        Else
            Call Quick3WayModMedianDouble(a(), i, r)
            Call Quick3WayModMedianDouble(a(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedianString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As String
    
    If r - L <= QuickCutoff Then
        Call InsertionString(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = (L + r) \ 2
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedianString(a(), L, j)
            Call Quick3WayModMedianString(a(), i, r)
        Else
            Call Quick3WayModMedianString(a(), i, r)
            Call Quick3WayModMedianString(a(), L, j)
        End If
    End If
End Sub

Public Sub pQuick3WayModMedianDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call pInsertionDouble(a(), Ptr(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = (L + r) \ 2
        temp = Ptr(r)
        Ptr(r) = Ptr(k)
        Ptr(k) = temp
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call pQuick3WayModMedianDouble(a(), Ptr(), L, j)
            Call pQuick3WayModMedianDouble(a(), Ptr(), i, r)
        Else
            Call pQuick3WayModMedianDouble(a(), Ptr(), i, r)
            Call pQuick3WayModMedianDouble(a(), Ptr(), L, j)
        End If
    End If
End Sub

Public Sub pQuick3WayModMedianString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call pInsertionString(a(), Ptr(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = (L + r) \ 2
        temp = Ptr(r)
        Ptr(r) = Ptr(k)
        Ptr(k) = temp
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call pQuick3WayModMedianString(a(), Ptr(), L, j)
            Call pQuick3WayModMedianString(a(), Ptr(), i, r)
        Else
            Call pQuick3WayModMedianString(a(), Ptr(), i, r)
            Call pQuick3WayModMedianString(a(), Ptr(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedian9Long(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Long
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call InsertionLong(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = GetMedianIndexLong(a(), L, r)
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedian9Long(a(), L, j)
            Call Quick3WayModMedian9Long(a(), i, r)
        Else
            Call Quick3WayModMedian9Long(a(), i, r)
            Call Quick3WayModMedian9Long(a(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedian9Double(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Double
    
    If r - L <= QuickCutoff Then
        Call InsertionDouble(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = GetMedianIndexDouble(a(), L, r)
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedian9Double(a(), L, j)
            Call Quick3WayModMedian9Double(a(), i, r)
        Else
            Call Quick3WayModMedian9Double(a(), i, r)
            Call Quick3WayModMedian9Double(a(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedian9String(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As String
    
    If r - L <= QuickCutoff Then
        Call InsertionString(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = GetMedianIndexString(a(), L, r)
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedian9String(a(), L, j)
            Call Quick3WayModMedian9String(a(), i, r)
        Else
            Call Quick3WayModMedian9String(a(), i, r)
            Call Quick3WayModMedian9String(a(), L, j)
        End If
    End If
End Sub

Public Sub pQuick3WayModMedian9Double(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call pInsertionDouble(a(), Ptr(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = pGetMedianIndexDouble(a(), Ptr(), L, r)
        temp = Ptr(r)
        Ptr(r) = Ptr(k)
        Ptr(k) = temp
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call pQuick3WayModMedian9Double(a(), Ptr(), L, j)
            Call pQuick3WayModMedian9Double(a(), Ptr(), i, r)
        Else
            Call pQuick3WayModMedian9Double(a(), Ptr(), i, r)
            Call pQuick3WayModMedian9Double(a(), Ptr(), L, j)
        End If
    End If
End Sub

Public Sub pQuick3WayModMedian9String(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call pInsertionString(a(), Ptr(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        k = pGetMedianIndexString(a(), Ptr(), L, r)
        temp = Ptr(r)
        Ptr(r) = Ptr(k)
        Ptr(k) = temp
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call pQuick3WayModMedian9String(a(), Ptr(), L, j)
            Call pQuick3WayModMedian9String(a(), Ptr(), i, r)
        Else
            Call pQuick3WayModMedian9String(a(), Ptr(), i, r)
            Call pQuick3WayModMedian9String(a(), Ptr(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedian9InlineLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Long
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call InsertionLong(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        Dim pl As Long
        Dim pm As Long
        Dim pn As Long
        Dim m As Long
        Dim n As Long
        Dim s As Long
        
        n = r - L + 1
        m = n \ 2
        '   Small arrays, middle element
        pm = m
        If n > 7 Then
            '   Mid-size, median of 3
            pl = L
            pn = r
            If n > 40 Then
                '   Big arrays, pseudomedian of 9
                s = n \ 8
                pl = Med3IndexLong(a(), pl, pl + s, pl + (2 * s))
                pm = Med3IndexLong(a(), pm - s, pm, pm + s)
                pn = Med3IndexLong(a(), pn - (2 * s), pn - s, pn)
            End If
            pm = Med3IndexLong(a(), pl, pm, pn)
        End If
        k = pm
'        k = GetMedianIndexLong(a(), L, r)
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedian9InlineLong(a(), L, j)
            Call Quick3WayModMedian9InlineLong(a(), i, r)
        Else
            Call Quick3WayModMedian9InlineLong(a(), i, r)
            Call Quick3WayModMedian9InlineLong(a(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedian9InlineDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Double
    
    If r - L <= QuickCutoff Then
        Call InsertionDouble(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        Dim pl As Long
        Dim pm As Long
        Dim pn As Long
        Dim m As Long
        Dim n As Long
        Dim s As Long
        
        n = r - L + 1
        m = n \ 2
        '   Small arrays, middle element
        pm = m
        If n > 7 Then
            '   Mid-size, median of 3
            pl = L
            pn = r
            If n > 40 Then
                '   Big arrays, pseudomedian of 9
                s = n \ 8
                pl = Med3IndexDouble(a(), pl, pl + s, pl + (2 * s))
                pm = Med3IndexDouble(a(), pm - s, pm, pm + s)
                pn = Med3IndexDouble(a(), pn - (2 * s), pn - s, pn)
            End If
            pm = Med3IndexDouble(a(), pl, pm, pn)
        End If
        k = pm
'        k = GetMedianIndexDouble(a(), L, r)
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedian9InlineDouble(a(), L, j)
            Call Quick3WayModMedian9InlineDouble(a(), i, r)
        Else
            Call Quick3WayModMedian9InlineDouble(a(), i, r)
            Call Quick3WayModMedian9InlineDouble(a(), L, j)
        End If
    End If
End Sub

Public Sub Quick3WayModMedian9InlineString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As String
    
    If r - L <= QuickCutoff Then
        Call InsertionString(a(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        Dim pl As Long
        Dim pm As Long
        Dim pn As Long
        Dim m As Long
        Dim n As Long
        Dim s As Long
        
        n = r - L + 1
        m = n \ 2
        '   Small arrays, middle element
        pm = m
        If n > 7 Then
            '   Mid-size, median of 3
            pl = L
            pn = r
            If n > 40 Then
                '   Big arrays, pseudomedian of 9
                s = n \ 8
                pl = Med3IndexString(a(), pl, pl + s, pl + (2 * s))
                pm = Med3IndexString(a(), pm - s, pm, pm + s)
                pn = Med3IndexString(a(), pn - (2 * s), pn - s, pn)
            End If
            pm = Med3IndexString(a(), pl, pm, pn)
        End If
        k = pm
'        k = GetMedianIndexString(a(), L, r)
        temp = a(r)
        a(r) = a(k)
        a(k) = temp
        v = a(r)
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(i) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(j)

            If i >= j Then
                Exit Do
            End If
            temp = a(i)
            a(i) = a(j)
            a(j) = temp
            If a(i) = v Then
                p = p + 1
                temp = a(p)
                a(p) = a(i)
                a(i) = temp
            End If
            If v = a(j) Then
                q = q - 1
                temp = a(q)
                a(q) = a(j)
                a(j) = temp
            End If
        Loop
        temp = a(i)
        a(i) = a(r)
        a(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = a(k)
            a(k) = a(j)
            a(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = a(k)
            a(k) = a(i)
            a(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call Quick3WayModMedian9InlineString(a(), L, j)
            Call Quick3WayModMedian9InlineString(a(), i, r)
        Else
            Call Quick3WayModMedian9InlineString(a(), i, r)
            Call Quick3WayModMedian9InlineString(a(), L, j)
        End If
    End If
End Sub

Public Sub pQuick3WayModMedian9InlineDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As Double
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call pInsertionDouble(a(), Ptr(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        Dim pl As Long
        Dim pm As Long
        Dim pn As Long
        Dim m As Long
        Dim n As Long
        Dim s As Long
        
        n = r - L + 1
        m = n \ 2
        '   Small arrays, middle element
        pm = m
        If n > 7 Then
            '   Mid-size, median of 3
            pl = L
            pn = r
            If n > 40 Then
                '   Big arrays, pseudomedian of 9
                s = n \ 8
                pl = pMed3IndexDouble(a(), Ptr(), pl, pl + s, pl + (2 * s))
                pm = pMed3IndexDouble(a(), Ptr(), pm - s, pm, pm + s)
                pn = pMed3IndexDouble(a(), Ptr(), pn - (2 * s), pn - s, pn)
            End If
            pm = pMed3IndexDouble(a(), Ptr(), pl, pm, pn)
        End If
        k = pm
'        k = pGetMedianIndexDouble(a(), Ptr(), L, r)
        temp = Ptr(r)
        Ptr(r) = Ptr(k)
        Ptr(k) = temp
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call pQuick3WayModMedian9InlineDouble(a(), Ptr(), L, j)
            Call pQuick3WayModMedian9InlineDouble(a(), Ptr(), i, r)
        Else
            Call pQuick3WayModMedian9InlineDouble(a(), Ptr(), i, r)
            Call pQuick3WayModMedian9InlineDouble(a(), Ptr(), L, j)
        End If
    End If
End Sub

Public Sub pQuick3WayModMedian9InlineString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 7.5, modified, with median, with pointers
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim q As Long
    Dim v As String
    Dim temp As Long
    
    If r - L <= QuickCutoff Then
        Call pInsertionString(a(), Ptr(), L, r)
        Exit Sub
    End If
    
    If r > L Then
        Dim pl As Long
        Dim pm As Long
        Dim pn As Long
        Dim m As Long
        Dim n As Long
        Dim s As Long
        
        n = r - L + 1
        m = n \ 2
        '   Small arrays, middle element
        pm = m
        If n > 7 Then
            '   Mid-size, median of 3
            pl = L
            pn = r
            If n > 40 Then
                '   Big arrays, pseudomedian of 9
                s = n \ 8
                pl = pMed3IndexString(a(), Ptr(), pl, pl + s, pl + (2 * s))
                pm = pMed3IndexString(a(), Ptr(), pm - s, pm, pm + s)
                pn = pMed3IndexString(a(), Ptr(), pn - (2 * s), pn - s, pn)
            End If
            pm = pMed3IndexString(a(), Ptr(), pl, pm, pn)
        End If
        k = pm
'        k = pGetMedianIndexString(a(), Ptr(), L, r)
        temp = Ptr(r)
        Ptr(r) = Ptr(k)
        Ptr(k) = temp
        v = a(Ptr(r))
        i = L - 1
        j = r
        p = i
        q = r

        Do
            Do
                i = i + 1
            Loop While a(Ptr(i)) < v
            Do
                If j = L Then

                    Exit Do
                End If
                j = j - 1
            Loop While v < a(Ptr(j))

            If i >= j Then
                Exit Do
            End If
            temp = Ptr(i)
            Ptr(i) = Ptr(j)
            Ptr(j) = temp
            If a(Ptr(i)) = v Then
                p = p + 1
                temp = Ptr(p)
                Ptr(p) = Ptr(i)
                Ptr(i) = temp
            End If
            If v = a(Ptr(j)) Then
                q = q - 1
                temp = Ptr(q)
                Ptr(q) = Ptr(j)
                Ptr(j) = temp
            End If
        Loop
        temp = Ptr(i)
        Ptr(i) = Ptr(r)
        Ptr(r) = temp
        j = i - 1
        i = i + 1
        For k = L To p - 1
            temp = Ptr(k)
            Ptr(k) = Ptr(j)
            Ptr(j) = temp
            j = j - 1
        Next k
        For k = r - 1 To q + 1 Step -1
            temp = Ptr(k)
            Ptr(k) = Ptr(i)
            Ptr(i) = temp
            i = i + 1
        Next k
        If j - L < r - i Then
            Call pQuick3WayModMedian9InlineString(a(), Ptr(), L, j)
            Call pQuick3WayModMedian9InlineString(a(), Ptr(), i, r)
        Else
            Call pQuick3WayModMedian9InlineString(a(), Ptr(), i, r)
            Call pQuick3WayModMedian9InlineString(a(), Ptr(), L, j)
        End If
    End If
End Sub

Public Sub SelectionLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As Long
    
    For i = L To r - 1
        min = i
        For j = i + 1 To r
            If a(j) < a(min) Then
                min = j
            End If
        Next j
        temp = a(i)
        a(i) = a(min)
        a(min) = temp
    Next i
End Sub

Public Sub SelectionDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As Double
    
    For i = L To r - 1
        min = i
        For j = i + 1 To r
            If a(j) < a(min) Then
                min = j
            End If
        Next j
        temp = a(i)
        a(i) = a(min)
        a(min) = temp
    Next i
End Sub

Public Sub SelectionString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As String
    
    For i = L To r - 1
        min = i
        For j = i + 1 To r
            If a(j) < a(min) Then
                min = j
            End If
        Next j
        temp = a(i)
        a(i) = a(min)
        a(min) = temp
    Next i
End Sub

Public Sub pSelectionDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2, pointers
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As Long
        
    For i = L To r - 1
        min = i
        For j = i + 1 To r
            If a(Ptr(j)) < a(Ptr(min)) Then
                min = j
            End If
        Next j
        temp = Ptr(min)
        Ptr(min) = Ptr(i)
        Ptr(i) = temp
    Next i
End Sub

Public Sub pSelectionString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2, pointers
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As Long
        
    For i = L To r - 1
        min = i
        For j = i + 1 To r
            If a(Ptr(j)) < a(Ptr(min)) Then
                min = j
            End If
        Next j
        temp = Ptr(min)
        Ptr(min) = Ptr(i)
        Ptr(i) = temp
    Next i
End Sub

Public Sub SelectionModLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2, modified
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As Long
    
    For i = L To r - 1
        min = i
        temp = a(i)
        For j = i + 1 To r
            If a(j) < temp Then
                min = j
                temp = a(j)
            End If
        Next j
        a(min) = a(i)
        a(i) = temp
    Next i
End Sub

Public Sub SelectionModDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2, modified
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As Double
    
    For i = L To r - 1
        min = i
        temp = a(i)
        For j = i + 1 To r
            If a(j) < temp Then
                min = j
                temp = a(j)
            End If
        Next j
        a(min) = a(i)
        a(i) = temp
    Next i
End Sub

Public Sub SelectionModString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2, modified
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As String
        
    For i = L To r - 1
        min = i
        temp = a(i)
        For j = i + 1 To r
            If a(j) < temp Then
                min = j
                temp = a(j)
            End If
        Next j
        a(min) = a(i)
        a(i) = temp
    Next i
End Sub

Public Sub pSelectionModDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2, modified, pointers
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As Long
        
    For i = L To r - 1
        min = i
        temp = Ptr(i)
        For j = i + 1 To r
            If a(Ptr(j)) < a(temp) Then
                min = j
                temp = Ptr(j)
            End If
        Next j
        Ptr(min) = Ptr(i)
        Ptr(i) = temp
    Next i
End Sub

Public Sub pSelectionModString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.2, modified, pointers
    Dim i As Long
    Dim j As Long
    Dim min As Long
    Dim temp As Long
        
    For i = L To r - 1
        min = i
        temp = Ptr(i)
        For j = i + 1 To r
            If a(Ptr(j)) < a(temp) Then
                min = j
                temp = Ptr(j)
            End If
        Next j
        Ptr(min) = Ptr(i)
        Ptr(i) = temp
    Next i
End Sub

Public Sub InsertionLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.3
    Dim i As Long
    Dim j As Long
    Dim v As Long
    
    For i = r To L + 1 Step -1
        If a(i - 1) > a(i) Then
            v = a(i)
            a(i) = a(i - 1)
            a(i - 1) = v
        End If
    Next i
    For i = L + 2 To r
        j = i
        v = a(i)
        Do While v < a(j - 1)
            a(j) = a(j - 1)
            j = j - 1
        Loop
        a(j) = v
    Next i
End Sub

Public Sub InsertionDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.3
    Dim i As Long
    Dim j As Long
    Dim v As Double
    
    For i = r To L + 1 Step -1
        If a(i - 1) > a(i) Then
            v = a(i)
            a(i) = a(i - 1)
            a(i - 1) = v
        End If
    Next i
    For i = L + 2 To r
        j = i
        v = a(i)
        Do While v < a(j - 1)
            a(j) = a(j - 1)
            j = j - 1
        Loop
        a(j) = v
    Next i
End Sub

Public Sub InsertionString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.3
    Dim i As Long
    Dim j As Long
    Dim v As String
    
    For i = r To L + 1 Step -1
        If a(i - 1) > a(i) Then
            v = a(i)
            a(i) = a(i - 1)
            a(i - 1) = v
        End If
    Next i
    For i = L + 2 To r
        j = i
        v = a(i)
        Do While v < a(j - 1)
            a(j) = a(j - 1)
            j = j - 1
        Loop
        a(j) = v
    Next i
End Sub

Public Sub pInsertionDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.3, modified to use pointers
    Dim i As Long
    Dim j As Long
    Dim v As Long
    
    For i = r To L + 1 Step -1
        If a(Ptr(i - 1)) > a(Ptr(i)) Then
            v = Ptr(i)
            Ptr(i) = Ptr(i - 1)
            Ptr(i - 1) = v
        End If
    Next i
    For i = L + 2 To r
        j = i
        v = Ptr(i)
        Do While a(v) < a(Ptr(j - 1))
            Ptr(j) = Ptr(j - 1)
            j = j - 1
        Loop
        Ptr(j) = v
    Next i
End Sub

Public Sub pInsertionString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.3, modified to use pointers
    Dim i As Long
    Dim j As Long
    Dim v As Long
    
    For i = r To L + 1 Step -1
        If a(Ptr(i - 1)) > a(Ptr(i)) Then
            v = Ptr(i)
            Ptr(i) = Ptr(i - 1)
            Ptr(i - 1) = v
        End If
    Next i
    For i = L + 2 To r
        j = i
        v = Ptr(i)
        Do While a(v) < a(Ptr(j - 1))
            Ptr(j) = Ptr(j - 1)
            j = j - 1
        Loop
        Ptr(j) = v
    Next i
End Sub

Public Sub BubbleLong(a() As Long, L As Long, r As Long)
    ' Sedgewick 6.4
    Dim i As Long
    Dim j As Long
    Dim temp As Long
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(j - 1) > a(j) Then
                temp = a(j)
                a(j) = a(j - 1)
                a(j - 1) = temp
            End If
        Next j
    Next i
End Sub

Public Sub BubbleDouble(a() As Double, L As Long, r As Long)
    ' Sedgewick 6.4
    Dim i As Long
    Dim j As Long
    Dim temp As Double
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(j - 1) > a(j) Then
                temp = a(j)
                a(j) = a(j - 1)
                a(j - 1) = temp
            End If
        Next j
    Next i
End Sub

Public Sub BubbleString(a() As String, L As Long, r As Long)
    ' Sedgewick 6.4
    Dim i As Long
    Dim j As Long
    Dim temp As String
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(j - 1) > a(j) Then
                temp = a(j)
                a(j) = a(j - 1)
                a(j - 1) = temp
            End If
        Next j
    Next i
End Sub

Public Sub pBubbleDouble(a() As Double, Ptr() As Long, L As Long, r As Long)
    ' Sedgewick 6.4, using pointers
    Dim i As Long
    Dim j As Long
    Dim temp As Long
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(Ptr(j - 1)) > a(Ptr(j)) Then
                temp = Ptr(j)
                Ptr(j) = Ptr(j - 1)
                Ptr(j - 1) = temp
            End If
        Next j
    Next i
End Sub

Public Sub pBubbleString(a() As String, Ptr() As Long, L As Long, r As Long)
    ' Sedgewick 6.4, using pointers
    Dim i As Long
    Dim j As Long
    Dim temp As Long
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(Ptr(j - 1)) > a(Ptr(j)) Then
                temp = Ptr(j)
                Ptr(j) = Ptr(j - 1)
                Ptr(j - 1) = temp
            End If
        Next j
    Next i
End Sub

Public Sub BubbleModLong(a() As Long, L As Long, r As Long)
    ' Sedgewick 6.4, modified
    Dim i As Long
    Dim j As Long
    Dim temp As Long
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(i) > a(j) Then
                temp = a(j)
                a(j) = a(i)
                a(i) = temp
            End If
        Next j
    Next i
End Sub

Public Sub BubbleModDouble(a() As Double, L As Long, r As Long)
    ' Sedgewick 6.4, modified
    Dim i As Long
    Dim j As Long
    Dim temp As Double
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(i) > a(j) Then
                temp = a(j)
                a(j) = a(i)
                a(i) = temp
            End If
        Next j
    Next i
End Sub

Public Sub BubbleModString(a() As String, L As Long, r As Long)
    ' Sedgewick 6.4, modified
    Dim i As Long
    Dim j As Long
    Dim temp As String
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(i) > a(j) Then
                temp = a(j)
                a(j) = a(i)
                a(i) = temp
            End If
        Next j
    Next i
End Sub

Public Sub pBubbleModDouble(a() As Double, Ptr() As Long, L As Long, r As Long)
    ' Sedgewick 6.4, modified and using pointers
    Dim i As Long
    Dim j As Long
    Dim temp As Long
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(Ptr(i)) > a(Ptr(j)) Then
                temp = Ptr(j)
                Ptr(j) = Ptr(i)
                Ptr(i) = temp
            End If
        Next j
    Next i
End Sub

Public Sub pBubbleModString(a() As String, Ptr() As Long, L As Long, r As Long)
    ' Sedgewick 6.4, modified and using pointers
    Dim i As Long
    Dim j As Long
    Dim temp As Long
    
    For i = L To r - 1
        For j = r To i + 1 Step -1
            If a(Ptr(i)) > a(Ptr(j)) Then
                temp = Ptr(j)
                Ptr(j) = Ptr(i)
                Ptr(i) = temp
            End If
        Next j
    Next i
End Sub

Public Sub ShellsortLong(a() As Long, L As Long, r As Long)
    ' Sedgewick 6.5
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim v As Long
    
    h = 1
    Do While h <= (r - L) \ 9
        h = 3 * h + 1
    Loop

    Do While h > 0
        For i = L + h To r
            v = a(i)
            j = i
            Do While (j >= L + h)
                If (v < a(j - h)) Then
                    a(j) = a(j - h)
                    j = j - h
                Else
                    Exit Do
                End If
            Loop
            a(j) = v
        Next i
        h = h \ 3
    Loop
End Sub

Public Sub ShellsortDouble(a() As Double, L As Long, r As Long)
    ' Sedgewick 6.5
    Dim v As Double
    Dim i As Long
    Dim j As Long
    Dim h As Long
    
    h = 1
    Do While h <= (r - L) \ 9
        h = 3 * h + 1
    Loop

    Do While h > 0
        For i = L + h To r
            v = a(i)
            j = i
            Do While (j >= L + h)
                If (v < a(j - h)) Then
                    a(j) = a(j - h)
                    j = j - h
                Else
                    Exit Do
                End If
            Loop
            a(j) = v
        Next i
        h = h \ 3
    Loop
End Sub

Public Sub ShellsortString(a() As String, L As Long, r As Long)
    ' Sedgewick 6.5
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim v As String
    
    h = 1
    Do While h <= (r - L) \ 9
        h = 3 * h + 1
    Loop

    Do While h > 0
        For i = L + h To r
            v = a(i)
            j = i
            Do While (j >= L + h)
                If (v < a(j - h)) Then
                    a(j) = a(j - h)
                    j = j - h
                Else
                    Exit Do
                End If
            Loop
            a(j) = v
        Next i
        h = h \ 3
    Loop
End Sub

Public Sub pShellsortDouble(a() As Double, Ptr() As Long, L As Long, r As Long)
    ' Sedgewick 6.5, using pointers
    Dim v As Double
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim temp As Long
    
    h = 1
    Do While h <= (r - L) \ 9
        h = 3 * h + 1
    Loop
    
    Do While h > 0
        For i = L + h To r
            temp = Ptr(i)
            v = a(temp)
            j = i
            Do While (j >= L + h)
                If (v < a(Ptr(j - h))) Then
                    Ptr(j) = Ptr(j - h)
                    j = j - h
                Else
                    Exit Do
                End If
            Loop
            Ptr(j) = temp
        Next i
        h = h \ 3
    Loop
End Sub

Public Sub pShellsortString(a() As String, Ptr() As Long, L As Long, r As Long)
    ' Sedgewick 6.5, using pointers
    Dim v As String
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim temp As Long
    
    h = 1
    Do While h <= (r - L) \ 9
        h = 3 * h + 1
    Loop
    
    Do While h > 0
        For i = L + h To r
            temp = Ptr(i)
            v = a(temp)
            j = i
            Do While (j >= L + h)
                If (v < a(Ptr(j - h))) Then
                    Ptr(j) = Ptr(j - h)
                    j = j - h
                Else
                    Exit Do
                End If
            Loop
            Ptr(j) = temp
        Next i
        h = h \ 3
    Loop
End Sub

Public Sub KeyIndexedLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.17
    Dim b() As Long
    Dim cnt() As Long
    Dim i As Long
    Dim j As Long
    Dim m As Long
    Dim Ptr As Long
    
    ReDim b(L To r)
    
    m = a(L)
    For i = L To r
        If a(i) > m Then
            m = a(i)
        End If
    Next i
    m = m + 1
    ReDim cnt(m)
    
    For j = 0 To m - 1
        cnt(j) = 0
    Next j
    For i = L To r
        Ptr = a(i) + 1
        cnt(Ptr) = cnt(Ptr) + 1
    Next i

    For j = 1 To m - 1
        cnt(j) = cnt(j) + cnt(j - 1)
    Next j
    For i = L To r
        Ptr = cnt(a(i))
        b(Ptr) = a(i)
        cnt(a(i)) = Ptr + 1
    Next i
    For i = L To r
        a(i) = b(i)
    Next i
End Sub

Public Sub KeyIndexedDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.17
    Dim b() As Double
    Dim cnt() As Long
    Dim i As Long
    Dim j As Long
    Dim m As Long
    Dim Ptr As Long
    
    ReDim b(L To r)
    
    m = a(L)
    For i = L To r
        If a(i) > m Then
            m = a(i)
        End If
    Next i
    m = m + 1
    ReDim cnt(m)
    
    For j = 0 To m - 1
        cnt(j) = 0
    Next j
    For i = L To r
        Ptr = a(i) + 1
        cnt(Ptr) = cnt(Ptr) + 1
    Next i

    For j = 1 To m - 1
        cnt(j) = cnt(j) + cnt(j - 1)
    Next j
    For i = L To r
        Ptr = cnt(a(i))
        b(Ptr) = a(i)
        cnt(a(i)) = Ptr + 1
    Next i
    For i = L To r
        a(i) = b(i)
    Next i
End Sub

Public Sub KeyIndexedString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 6.17
    Dim b() As String
    Dim cnt() As Long
    Dim i As Long
    Dim j As Long
    Dim m As Long
    Dim Ptr As Long
    Dim temp As Long
    
    ReDim b(L To r)
    
    m = CLng(a(L))
    For i = L To r
        If CLng(a(i)) > m Then
            m = CLng(a(i))
        End If
    Next i
    m = m + 1
    ReDim cnt(m)
    
    For j = 0 To m - 1
        cnt(j) = 0
    Next j
    For i = L To r
        Ptr = CLng(a(i)) + 1
        cnt(Ptr) = cnt(Ptr) + 1
    Next i

    For j = 1 To m - 1
        cnt(j) = cnt(j) + cnt(j - 1)
    Next j
    For i = L To r
        temp = CLng(a(i))
        Ptr = cnt(temp)
        b(Ptr) = a(i)
        cnt(temp) = Ptr + 1
    Next i
    For i = L To r
        a(i) = b(i)
    Next i
End Sub

Public Sub HKKeyIndexedLong(a() As Long)
    ' Sedgewick 6.17, modified
    Dim cnt() As Long
    Dim i As Long
    Dim j As Long
    Dim m As Long
    Dim r As Long
    Dim Ptr As Long
        
    m = a(0)
    r = UBound(a)
    For i = 0 To r
        If a(i) > m Then
            m = a(i)
        End If
    Next i
    ReDim cnt(m)
    
    For j = 0 To m
        cnt(j) = 0
    Next j
    For i = 0 To r
        Ptr = a(i)
        cnt(Ptr) = cnt(Ptr) + 1
    Next i
    
    Ptr = 0
    For i = 0 To m
        For j = 1 To cnt(i)
            a(Ptr) = i
            Ptr = Ptr + 1
        Next j
    Next i
End Sub

Public Sub HKKeyIndexedDouble(a() As Double)
    ' Sedgewick 6.17, modified
    Dim cnt() As Long
    Dim i As Long
    Dim j As Long
    Dim m As Long
    Dim r As Long
    Dim Ptr As Long
        
    m = a(0)
    r = UBound(a)
    For i = 0 To r
        If a(i) > m Then
            m = a(i)
        End If
    Next i
    ReDim cnt(m)
    
    For j = 0 To m
        cnt(j) = 0
    Next j
    For i = 0 To r
        Ptr = a(i)
        cnt(Ptr) = cnt(Ptr) + 1
    Next i
    
    Ptr = 0
    For i = 0 To m
        For j = 1 To cnt(i)
            a(Ptr) = i
            Ptr = Ptr + 1
        Next j
    Next i
End Sub

Public Sub HKKeyIndexedString(a() As String)
    ' Sedgewick 6.17, modified
    Dim cnt() As Long
    Dim i As Long
    Dim j As Long
    Dim m As Long
    Dim r As Long
    Dim Ptr As Long
    Dim temp As String
        
    m = CLng(a(0))
    r = UBound(a)
    For i = 0 To r
        If CLng(a(i)) > m Then
            m = CLng(a(i))
        End If
    Next i
    ReDim cnt(m)
    
    For j = 0 To m
        cnt(j) = 0
    Next j
    For i = 0 To r
        Ptr = CLng(a(i))
        cnt(Ptr) = cnt(Ptr) + 1
    Next i
    
    Ptr = 0
    For i = 0 To m
        temp = AlignNumberLong(i)
        For j = 1 To cnt(i)
            a(Ptr) = temp
            Ptr = Ptr + 1
        Next j
    Next i
End Sub

Public Sub MergeLong(a() As Long, aux() As Long, ByVal L As Long, ByVal m As Long, ByVal r As Long)
    ' Sedgewick 8.2
    ' Abstract in-place merge
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim rm As Long

    For i = m + 1 To L + 1 Step -1
        aux(i - 1) = a(i - 1)
    Next i
    rm = r + m
    For j = m To r - 1
        aux(rm - j) = a(j + 1)
    Next j
    For k = L To r
        If aux(j) < aux(i) Then
            a(k) = aux(j)
            j = j - 1
        Else
            a(k) = aux(i)
            i = i + 1
        End If
    Next k
End Sub

Public Sub MergeDouble(a() As Double, aux() As Double, ByVal L As Long, ByVal m As Long, ByVal r As Long)
    ' Sedgewick 8.2
    ' Abstract in-place merge
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim rm As Long
    
    For i = m + 1 To L + 1 Step -1
        aux(i - 1) = a(i - 1)
    Next i
    rm = r + m
    For j = m To r - 1
        aux(rm - j) = a(j + 1)
    Next j
    For k = L To r
        If aux(j) < aux(i) Then
            a(k) = aux(j)
            j = j - 1
        Else
            a(k) = aux(i)
            i = i + 1
        End If
    Next k
End Sub

Public Sub MergeString(a() As String, aux() As String, ByVal L As Long, ByVal m As Long, ByVal r As Long)
    ' Sedgewick 8.2
    ' Abstract in-place merge
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim rm As Long
    
    For i = m + 1 To L + 1 Step -1
        aux(i - 1) = a(i - 1)
    Next i
    rm = r + m
    For j = m To r - 1
        aux(rm - j) = a(j + 1)
    Next j
    For k = L To r
        If aux(j) < aux(i) Then
            a(k) = aux(j)
            j = j - 1
        Else
            a(k) = aux(i)
            i = i + 1
        End If
    Next k
End Sub

Public Sub pMergeDouble(a() As Double, aux() As Double, pa() As Long, paux() As Long, _
    ByVal L As Long, ByVal m As Long, ByVal r As Long)
    ' Sedgewick 8.2, using pointers
    ' Abstract in-place merge
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim rm As Long
    
    For i = m + 1 To L + 1 Step -1
        paux(i - 1) = pa(i - 1)
    Next i
    rm = r + m
    For j = m To r - 1
        paux(rm - j) = pa(j + 1)
    Next j
    For k = L To r
        If aux(paux(j)) < aux(paux(i)) Then
            pa(k) = paux(j)
            j = j - 1
        Else
            pa(k) = paux(i)
            i = i + 1
        End If
    Next k
End Sub

Public Sub pMergeString(a() As String, aux() As String, pa() As Long, paux() As Long, _
    ByVal L As Long, ByVal m As Long, ByVal r As Long)
    ' Sedgewick 8.2, using pointers
    ' Abstract in-place merge
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim rm As Long
    
    For i = m + 1 To L + 1 Step -1
        paux(i - 1) = pa(i - 1)
    Next i
    rm = r + m
    For j = m To r - 1
        paux(rm - j) = pa(j + 1)
    Next j
    For k = L To r
        If aux(paux(j)) < aux(paux(i)) Then
            pa(k) = paux(j)
            j = j - 1
        Else
            pa(k) = paux(i)
            i = i + 1
        End If
    Next k
End Sub

Public Sub MergeSortTDLong(a() As Long, aux() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.3
    ' Top-down mergesort
    Dim m As Long
    
    If r > L Then
        m = (r + L) \ 2
        Call MergeSortTDLong(a(), aux(), L, m)
        Call MergeSortTDLong(a(), aux(), m + 1, r)
        Call MergeLong(a(), aux(), L, m, r)
    End If
End Sub

Public Sub MergeSortTDDouble(a() As Double, aux() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.3
    ' Top-down mergesort
    Dim m As Long
    
    If r > L Then
        m = (r + L) \ 2
        Call MergeSortTDDouble(a(), aux(), L, m)
        Call MergeSortTDDouble(a(), aux(), m + 1, r)
        Call MergeDouble(a(), aux(), L, m, r)
    End If
End Sub

Public Sub MergeSortTDString(a() As String, aux() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.3
    ' Top-down mergesort
    Dim m As Long
    
    If r > L Then
        m = (r + L) \ 2
        Call MergeSortTDString(a(), aux(), L, m)
        Call MergeSortTDString(a(), aux(), m + 1, r)
        Call MergeString(a(), aux(), L, m, r)
    End If
End Sub

Public Sub pMergeSortTDMainDouble(a() As Double, aux() As Double, pa() As Long, paux() As Long, _
    ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.3, with pointers
    ' Top-down mergesort
    Dim i As Long
    
    ReDim aux(L To r)
    ReDim paux(L To r)
    ReDim pa(L To r)
    For i = 0 To r
        pa(i) = i
        paux(i) = i
        aux(i) = a(i)
    Next i
    Call pMergeSortTDDouble(a(), aux(), pa(), paux(), L, r)
End Sub

Public Sub pMergeSortTDDouble(a() As Double, aux() As Double, pa() As Long, paux() As Long, _
    ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.3, with pointers
    ' Top-down mergesort
    Dim m As Long
    
    If r > L Then
        m = (r + L) \ 2
        Call pMergeSortTDDouble(a(), aux(), pa(), paux(), L, m)
        Call pMergeSortTDDouble(a(), aux(), pa(), paux(), m + 1, r)
        Call pMergeDouble(a(), aux(), pa(), paux(), L, m, r)
    End If
End Sub

Public Sub pMergeSortTDMainString(a() As String, aux() As String, pa() As Long, paux() As Long, _
    ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.3, with pointers
    ' Top-down mergesort
    Dim i As Long
    
    ReDim aux(L To r)
    ReDim paux(L To r)
    ReDim pa(L To r)
    For i = 0 To r
        pa(i) = i
        paux(i) = i
        aux(i) = a(i)
    Next i
    Call pMergeSortTDString(a(), aux(), pa(), paux(), L, r)
End Sub

Public Sub pMergeSortTDString(a() As String, aux() As String, pa() As Long, paux() As Long, _
    ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.3, with pointers
    ' Top-down mergesort
    Dim m As Long
    
    If r > L Then
        m = (r + L) \ 2
        Call pMergeSortTDString(a(), aux(), pa(), paux(), L, m)
        Call pMergeSortTDString(a(), aux(), pa(), paux(), m + 1, r)
        Call pMergeString(a(), aux(), pa(), paux(), L, m, r)
    End If
End Sub

Public Sub MergeSortABrModMainLong(a() As Long, aux() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    ReDim aux(L To r)
    
    For i = L To r
        aux(i) = a(i)
    Next i
    Call MergeSortABrModLong(a(), aux(), L, r)
    ReDim aux(0)
End Sub

Sub MergeSortABrModLong(a() As Long, b() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, modified
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call MergeSortABrModLong(a(), b(), L, m)
        Call MergeSortABrModLong(a(), b(), m + 1, r)
        i = L
        j = m + 1
        k = L
        Do
            If a(i) > a(j) Then
                b(k) = a(j)
                k = k + 1
                j = j + 1
                If j > r Then
                    Do
                        b(k) = a(i)
                        k = k + 1
                        i = i + 1
                    Loop Until i > m
                    Exit Do
                End If
            Else
                b(k) = a(i)
                k = k + 1
                i = i + 1
                If i > m Then
                    Do
                        b(k) = a(j)
                        k = k + 1
                        j = j + 1
                    Loop Until j > r
                    Exit Do
                End If
            End If
        Loop
        For k = L To r
             a(k) = b(k)
        Next k
    Else
        Call InsertionLong(a(), L, r)
    End If
End Sub

Public Sub MergeSortABrModMainDouble(a() As Double, aux() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    ReDim aux(L To r)
    
    For i = L To r
        aux(i) = a(i)
    Next i
    Call MergeSortABrModDouble(a(), aux(), L, r)
End Sub

Sub MergeSortABrModDouble(a() As Double, b() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, modified
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call MergeSortABrModDouble(a(), b(), L, m)
        Call MergeSortABrModDouble(a(), b(), m + 1, r)
        i = L
        j = m + 1
        k = L
        Do
            If a(i) > a(j) Then
                b(k) = a(j)
                k = k + 1
                j = j + 1
                If j > r Then
                    Do
                        b(k) = a(i)
                        k = k + 1
                        i = i + 1
                    Loop Until i > m
                    Exit Do
                End If
            Else
                b(k) = a(i)
                k = k + 1
                i = i + 1
                If i > m Then
                    Do
                        b(k) = a(j)
                        k = k + 1
                        j = j + 1
                    Loop Until j > r
                    Exit Do
                End If
            End If
        Loop
        For k = L To r
             a(k) = b(k)
        Next k
    Else
        Call InsertionDouble(a(), L, r)
    End If
End Sub

Public Sub MergeSortABrModMainString(a() As String, aux() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    ReDim aux(L To r)
    
    For i = L To r
        aux(i) = a(i)
    Next i
    Call MergeSortABrModString(a(), aux(), L, r)
End Sub

Public Sub MergeSortABrModString(a() As String, b() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, modified
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call MergeSortABrModString(a(), b(), L, m)
        Call MergeSortABrModString(a(), b(), m + 1, r)
        i = L
        j = m + 1
        k = L
        Do
            If a(i) > a(j) Then
                b(k) = a(j)
                k = k + 1
                j = j + 1
                If j > r Then
                    Do
                        b(k) = a(i)
                        k = k + 1
                        i = i + 1
                    Loop Until i > m
                    Exit Do
                End If
            Else
                b(k) = a(i)
                k = k + 1
                i = i + 1
                If i > m Then
                    Do
                        b(k) = a(j)
                        k = k + 1
                        j = j + 1
                    Loop Until j > r
                    Exit Do
                End If
            End If
        Loop
        For k = L To r
             a(k) = b(k)
        Next k
    Else
        Call InsertionString(a(), L, r)
    End If
End Sub

Public Sub pMergeSortABrModMainDouble(a() As Double, Ptr() As Long, ptr1() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, uses pointers
    Dim i As Long
    ReDim Ptr(L To r)
    ReDim ptr1(L To r)
    
    For i = L To r
        Ptr(i) = i
        ptr1(i) = i
    Next i
    Call pMergeSortABrModDouble(a(), Ptr(), ptr1(), L, r)
End Sub

Sub pMergeSortABrModDouble(a() As Double, Ptr() As Long, ptr1() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, modified
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call pMergeSortABrModDouble(a(), Ptr(), ptr1(), L, m)
        Call pMergeSortABrModDouble(a(), Ptr(), ptr1(), m + 1, r)
        i = L
        j = m + 1
        k = L
        Do
            If a(Ptr(i)) > a(Ptr(j)) Then
                ptr1(k) = Ptr(j)
                k = k + 1
                j = j + 1
                If j > r Then
                    Do
                        ptr1(k) = Ptr(i)
                        k = k + 1
                        i = i + 1
                    Loop Until i > m
                    Exit Do
                End If
            Else
                ptr1(k) = Ptr(i)
                k = k + 1
                i = i + 1
                If i > m Then
                    Do
                        ptr1(k) = Ptr(j)
                        k = k + 1
                        j = j + 1
                    Loop Until j > r
                    Exit Do
                End If
            End If
        Loop
        For k = L To r
             Ptr(k) = ptr1(k)
        Next k
    Else
        Call pInsertionDouble(a(), Ptr(), L, r)
    End If
End Sub

Public Sub pMergeSortABrModMainString(a() As String, Ptr() As Long, ptr1() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, uses pointers
    Dim i As Long
    ReDim Ptr(L To r)
    ReDim ptr1(L To r)
    
    For i = L To r
        Ptr(i) = i
        ptr1(i) = i
    Next i
    Call pMergeSortABrModString(a(), Ptr(), ptr1(), L, r)
End Sub

Sub pMergeSortABrModString(a() As String, Ptr() As Long, ptr1() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, modified
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call pMergeSortABrModString(a(), Ptr(), ptr1(), L, m)
        Call pMergeSortABrModString(a(), Ptr(), ptr1(), m + 1, r)
        i = L
        j = m + 1
        k = L
        Do
            If a(Ptr(i)) > a(Ptr(j)) Then
                ptr1(k) = Ptr(j)
                k = k + 1
                j = j + 1
                If j > r Then
                    Do
                        ptr1(k) = Ptr(i)
                        k = k + 1
                        i = i + 1
                    Loop Until i > m
                    Exit Do
                End If
            Else
                ptr1(k) = Ptr(i)
                k = k + 1
                i = i + 1
                If i > m Then
                    Do
                        ptr1(k) = Ptr(j)
                        k = k + 1
                        j = j + 1
                    Loop Until j > r
                    Exit Do
                End If
            End If
        Loop
        For k = L To r
             Ptr(k) = ptr1(k)
        Next k
    Else
        Call pInsertionString(a(), Ptr(), L, r)
    End If
End Sub

Public Sub MergeSortBULong(a() As Long, aux() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.5
    ' Bottom-up mergesort
    Dim i As Long
    Dim lngMin As Long
    Dim lng2M As Long
    Dim m As Long
    ReDim aux(L To r)
    
    m = 1
    Do While m <= r - L
        i = L
        lng2M = m + m
        Do While i <= r - m
            lngMin = i + lng2M - 1
            If r < lngMin Then
                lngMin = r
            End If
            Call MergeLong(a(), aux(), i, i + m - 1, lngMin)
            i = i + m + m
        Loop
        m = m + m
    Loop
    ReDim aux(0)
End Sub

Public Sub MergeSortBUDouble(a() As Double, aux() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.5
    ' Bottom-up mergesort
    Dim i As Long
    Dim lngMin As Long
    Dim lng2M As Long
    Dim m As Long
    ReDim aux(L To r)
    
    m = 1
    Do While m <= r - L
        i = L
        lng2M = m + m
        Do While i <= r - m
            lngMin = i + lng2M - 1
            If r < lngMin Then
                lngMin = r
            End If
            Call MergeDouble(a(), aux(), i, i + m - 1, lngMin)
            i = i + m + m
        Loop
        m = m + m
    Loop
    ReDim aux(0)
End Sub

Public Sub MergeSortBUString(a() As String, aux() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.5
    ' Bottom-up mergesort
    Dim i As Long
    Dim lngMin As Long
    Dim lng2M As Long
    Dim m As Long
    ReDim aux(L To r)
    
    m = 1
    Do While m <= r - L
        i = L
        lng2M = m + m
        Do While i <= r - m
            lngMin = i + lng2M - 1
            If r < lngMin Then
                lngMin = r
            End If
            Call MergeString(a(), aux(), i, i + m - 1, lngMin)
            i = i + m + m
        Loop
        m = m + m
    Loop
    ReDim aux(0)
End Sub

Public Sub pMergeSortBUDouble(a() As Double, aux() As Double, pa() As Long, paux() As Long, _
    ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.5, using pointers
    ' Bottom-up mergesort
    Dim i As Long
    Dim lngMin As Long
    Dim lng2M As Long
    Dim m As Long
    ReDim aux(L To r)
    ReDim paux(L To r)
    ReDim pa(L To r)
    
    For i = 0 To r
        pa(i) = i
        paux(i) = i
        aux(i) = a(i)
    Next i
    
    m = 1
    Do While m <= r - L
        i = L
        lng2M = m + m
        Do While i <= r - m
            lngMin = i + lng2M - 1
            If r < lngMin Then
                lngMin = r
            End If
            Call pMergeDouble(a(), aux(), pa(), paux(), i, i + m - 1, lngMin)
            i = i + m + m
        Loop
        m = m + m
    Loop
    ReDim aux(0)
End Sub

Public Sub pMergeSortBUString(a() As String, aux() As String, pa() As Long, paux() As Long, _
    ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.5, using pointers
    ' Bottom-up mergesort
    Dim i As Long
    Dim lngMin As Long
    Dim lng2M As Long
    Dim m As Long
    ReDim aux(L To r)
    ReDim pa(L To r)
    ReDim paux(L To r)
    
    For i = 0 To r
        pa(i) = i
        paux(i) = i
        aux(i) = a(i)
    Next i
    
    m = 1
    Do While m <= r - L
        i = L
        lng2M = m + m
        Do While i <= r - m
            lngMin = i + lng2M - 1
            If r < lngMin Then
                lngMin = r
            End If
            Call pMergeString(a(), aux(), pa(), paux(), i, i + m - 1, lngMin)
            i = i + m + m
        Loop
        m = m + m
    Loop
    ReDim aux(0)
End Sub

Public Sub MergeSortABrMainLong(a() As Long, aux() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    ReDim aux(L To r)
    
    For i = L To r
        aux(i) = a(i)
    Next i
    Call MergeSortABrLong(a(), aux(), L, r)
    ReDim aux(0)
End Sub

Sub MergeSortABrLong(a() As Long, b() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call MergeSortABrLong(a(), b(), L, m)
        Call MergeSortABrLong(a(), b(), m + 1, r)
        i = L
        j = m + 1
        For k = L To r
            Do
                If i = m + 1 Then
                    b(k) = a(j)
                    j = j + 1
                    Exit Do
                End If
                If j = r + 1 Then
                    b(k) = a(i)
                    i = i + 1
                    Exit Do
                End If
                If a(i) > a(j) Then
                    b(k) = a(j)
                    j = j + 1
                Else
                    b(k) = a(i)
                    i = i + 1
                End If
                Exit Do
            Loop
        Next k
        For k = L To r
             a(k) = b(k)
        Next k
    Else
        Call InsertionLong(a(), L, r)
    End If
End Sub

Public Sub MergeSortABrMainDouble(a() As Double, aux() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    ReDim aux(L To r)
    
    For i = L To r
        aux(i) = a(i)
    Next i
    Call MergeSortABrDouble(a(), aux(), L, r)
End Sub

Sub MergeSortABrDouble(a() As Double, b() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call MergeSortABrDouble(a(), b(), L, m)
        Call MergeSortABrDouble(a(), b(), m + 1, r)
        i = L
        j = m + 1
        For k = L To r
            Do
                If i = m + 1 Then
                    b(k) = a(j)
                    j = j + 1
                    Exit Do
                End If
                If j = r + 1 Then
                    b(k) = a(i)
                    i = i + 1
                    Exit Do
                End If
                If a(i) > a(j) Then
                    b(k) = a(j)
                    j = j + 1
                Else
                    b(k) = a(i)
                    i = i + 1
                End If
                Exit Do
            Loop
        Next k
        For k = L To r
             a(k) = b(k)
        Next k
    Else
        Call InsertionDouble(a(), L, r)
    End If
End Sub

Public Sub MergeSortABrMainString(a() As String, aux() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    ReDim aux(L To r)
    
    For i = L To r
        aux(i) = a(i)
    Next i
    Call MergeSortABrString(a(), aux(), L, r)
End Sub

Public Sub MergeSortABrString(a() As String, b() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call MergeSortABrString(a(), b(), L, m)
        Call MergeSortABrString(a(), b(), m + 1, r)
        i = L
        j = m + 1
        For k = L To r
            Do
                If i = m + 1 Then
                    b(k) = a(j)
                    j = j + 1
                    Exit Do
                End If
                If j = r + 1 Then
                    b(k) = a(i)
                    i = i + 1
                    Exit Do
                End If
                If a(i) > a(j) Then
                    b(k) = a(j)
                    j = j + 1
                Else
                    b(k) = a(i)
                    i = i + 1
                End If
                Exit Do
            Loop
        Next k
        For k = L To r
             a(k) = b(k)
        Next k
    Else
        Call InsertionString(a(), L, r)
    End If
End Sub

Public Sub pMergeSortABrMainDouble(a() As Double, Ptr() As Long, ptr1() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, uses pointers
    Dim i As Long
    ReDim Ptr(L To r)
    ReDim ptr1(L To r)
    
    For i = L To r
        Ptr(i) = i
        ptr1(i) = i
    Next i
    Call pMergeSortABrDouble(a(), Ptr(), ptr1(), L, r)
End Sub

Sub pMergeSortABrDouble(a() As Double, Ptr() As Long, ptr1() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call pMergeSortABrDouble(a(), Ptr(), ptr1(), L, m)
        Call pMergeSortABrDouble(a(), Ptr(), ptr1(), m + 1, r)
        i = L
        j = m + 1
        For k = L To r
            Do
                If i = m + 1 Then
                    ptr1(k) = Ptr(j)
                    j = j + 1
                    Exit Do
                End If
                If j = r + 1 Then
                    ptr1(k) = Ptr(i)
                    i = i + 1
                    Exit Do
                End If
                If a(Ptr(i)) > a(Ptr(j)) Then
                    ptr1(k) = Ptr(j)
                    j = j + 1
                Else
                    ptr1(k) = Ptr(i)
                    i = i + 1
                End If
                Exit Do
            Loop
        Next k
        For k = L To r
             Ptr(k) = ptr1(k)
        Next k
    Else
        Call pInsertionDouble(a(), Ptr(), L, r)
    End If
End Sub

Public Sub pMergeSortABrMainString(a() As String, Ptr() As Long, ptr1() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying, uses pointers
    Dim i As Long
    ReDim Ptr(L To r)
    ReDim ptr1(L To r)
    
    For i = L To r
        Ptr(i) = i
        ptr1(i) = i
    Next i
    Call pMergeSortABrString(a(), Ptr(), ptr1(), L, r)
End Sub

Sub pMergeSortABrString(a() As String, Ptr() As Long, ptr1() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 8.4: Mergesort with no copying
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim m As Long
    
    If r - L > MergeCutoff Then
        m = (L + r) \ 2
        Call pMergeSortABrString(a(), Ptr(), ptr1(), L, m)
        Call pMergeSortABrString(a(), Ptr(), ptr1(), m + 1, r)
        i = L
        j = m + 1
        For k = L To r
            Do
                If i = m + 1 Then
                    ptr1(k) = Ptr(j)
                    j = j + 1
                    Exit Do
                End If
                If j = r + 1 Then
                    ptr1(k) = Ptr(i)
                    i = i + 1
                    Exit Do
                End If
                If a(Ptr(i)) > a(Ptr(j)) Then
                    ptr1(k) = Ptr(j)
                    j = j + 1
                Else
                    ptr1(k) = Ptr(i)
                    i = i + 1
                End If
                Exit Do
            Loop
        Next k
        For k = L To r
             Ptr(k) = ptr1(k)
        Next k
    Else
        Call pInsertionString(a(), Ptr(), L, r)
    End If
End Sub

Private Sub fixDownLong(a() As Long, ByVal L As Long, ByVal r As Long, ByVal k As Long)
    ' Sedgewick 9.4: Top-down heapify, modified
    Dim j As Long
    Dim temp As Long
    
    Do
        j = 2 * k - (L - 1)
        If j > r Then
            Exit Sub
        Else
            If j < r Then
                If a(j) < a(j + 1) Then
                    j = j + 1
                End If
            End If
                
            If a(k) < a(j) Then
                temp = a(k)
                a(k) = a(j)
                a(j) = temp
                k = j
            Else
                Exit Sub
            End If
        End If
    Loop
End Sub

Private Sub fixDownDouble(a() As Double, ByVal L As Long, ByVal r As Long, ByVal k As Long)
    ' Sedgewick 9.4: Top-down heapify, modified
    Dim j As Long
    Dim temp As Double
    
    Do
        j = 2 * k - (L - 1)
        If j > r Then
            Exit Sub
        Else
            If j < r Then
                If a(j) < a(j + 1) Then
                    j = j + 1
                End If
            End If
                
            If a(k) < a(j) Then
                temp = a(k)
                a(k) = a(j)
                a(j) = temp
                k = j
            Else
                Exit Sub
            End If
        End If
    Loop
End Sub

Private Sub fixDownString(a() As String, ByVal L As Long, ByVal r As Long, ByVal k As Long)
    ' Sedgewick 9.4: Top-down heapify, modified
    Dim j As Long
    Dim temp As String
    
    Do
        j = 2 * k - (L - 1)
        If j > r Then
            Exit Sub
        Else
            If j < r Then
                If a(j) < a(j + 1) Then
                    j = j + 1
                End If
            End If
                
            If a(k) < a(j) Then
                temp = a(k)
                a(k) = a(j)
                a(j) = temp
                k = j
            Else
                Exit Sub
            End If
        End If
    Loop
End Sub

Private Sub pfixDownDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long, ByVal k As Long)
    ' Sedgewick 9.4: Top-down heapify, modified
    Dim j As Long
    Dim temp As Long
    
    Do
        j = 2 * k - (L - 1)
        If j > r Then
            Exit Sub
        Else
            If j < r Then
                If a(Ptr(j)) < a(Ptr(j + 1)) Then
                    j = j + 1
                End If
            End If
                
            If a(Ptr(k)) < a(Ptr(j)) Then
                temp = Ptr(k)
                Ptr(k) = Ptr(j)
                Ptr(j) = temp
                k = j
            Else
                Exit Sub
            End If
        End If
    Loop
End Sub

Private Sub pfixDownString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long, ByVal k As Long)
    ' Sedgewick 9.4: Top-down heapify, modified
    Dim j As Long
    Dim temp As Long
    
    Do
        j = 2 * k - (L - 1)
        If j > r Then
            Exit Sub
        Else
            If j < r Then
                If a(Ptr(j)) < a(Ptr(j + 1)) Then
                    j = j + 1
                End If
            End If
                
            If a(Ptr(k)) < a(Ptr(j)) Then
                temp = Ptr(k)
                Ptr(k) = Ptr(j)
                Ptr(j) = temp
                k = j
            Else
                Exit Sub
            End If
        End If
    Loop
End Sub

Public Sub HeapsortLong(a() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 9.7, modified
    Dim k As Long
    Dim temp As Long
    
    For k = (r - L + 1) \ 2 To L Step -1
        Call fixDownLong(a(), L, r, k)
    Next k
    
    For k = r To L + 1 Step -1
        temp = a(L)
        a(L) = a(k)
        a(k) = temp
        Call fixDownLong(a(), L, k - 1, L)
    Next k
End Sub

Public Sub HeapsortDouble(a() As Double, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 9.7, modified
    Dim k As Long
    Dim temp As Double
    
    For k = (r - L + 1) \ 2 To L Step -1
        Call fixDownDouble(a(), L, r, k)
    Next k
    
    For k = r To L + 1 Step -1
        temp = a(L)
        a(L) = a(k)
        a(k) = temp
        Call fixDownDouble(a(), L, k - 1, L)
    Next k
End Sub

Public Sub HeapsortString(a() As String, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 9.7, modified
    Dim k As Long
    Dim temp As String
    
    For k = (r - L + 1) \ 2 To L Step -1
        Call fixDownString(a(), L, r, k)
    Next k
    
    For k = r To L + 1 Step -1
        temp = a(L)
        a(L) = a(k)
        a(k) = temp
        Call fixDownString(a(), L, k - 1, L)
    Next k
End Sub

Public Sub pHeapsortDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 9.7, modified
    Dim k As Long
    Dim temp As Long
    
    ReDim Ptr(L To r)
    For k = L To r
        Ptr(k) = k
    Next k
    
    For k = (r - L + 1) \ 2 To L Step -1
        Call pfixDownDouble(a(), Ptr(), L, r, k)
    Next k
    
    For k = r To L + 1 Step -1
        temp = Ptr(L)
        Ptr(L) = Ptr(k)
        Ptr(k) = temp
        Call pfixDownDouble(a(), Ptr(), L, k - 1, L)
    Next k
End Sub

Public Sub pHeapsortString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    ' Sedgewick 9.7, modified
    Dim k As Long
    Dim temp As Long
    
    ReDim Ptr(L To r)
    For k = L To r
        Ptr(k) = k
    Next k
    
    For k = (r - L + 1) \ 2 To L Step -1
        Call pfixDownString(a(), Ptr(), L, r, k)
    Next k
    
    For k = r To L + 1 Step -1
        temp = Ptr(L)
        Ptr(L) = Ptr(k)
        Ptr(k) = temp
        Call pfixDownString(a(), Ptr(), L, k - 1, L)
    Next k
End Sub

Private Function GetMedianIndexLong(a() As Long, ByVal L As Long, ByVal r As Long) As Long
    ' Jon L. Bentley and M. Douglas McILroy, Engineering a Sort Function
    ' Software-Practice and Experience, vol. 23(11), 1249-1265 (November 1993)
    Dim pl As Long
    Dim pm As Long
    Dim pn As Long
    Dim m As Long
    Dim n As Long
    Dim s As Long
    
    n = r - L + 1
    m = n \ 2
    '   Small arrays, middle element
    pm = m
    If n > 7 Then
        '   Mid-size, median of 3
        pl = L
        pn = r
        If n > 40 Then
            '   Big arrays, pseudomedian of 9
            s = n \ 8
            pl = Med3IndexLong(a(), pl, pl + s, pl + (2 * s))
            pm = Med3IndexLong(a(), pm - s, pm, pm + s)
            pn = Med3IndexLong(a(), pn - (2 * s), pn - s, pn)
        End If
        pm = Med3IndexLong(a(), pl, pm, pn)
    End If
    GetMedianIndexLong = pm
End Function

Private Function Med3IndexLong(D() As Long, a As Long, b As Long, c As Long) As Long
    Dim med As Long
    If D(a) < D(b) Then
        If D(b) < D(c) Then
            med = b
        Else
            If D(a) < D(c) Then
                med = c
            Else
                med = a
            End If
        End If
    Else
        If D(b) > D(c) Then
            med = b
        Else
            If D(a) > D(c) Then
                med = c
            Else
                med = a
            End If
        End If
    End If
    Med3IndexLong = med
End Function

Private Function GetMedianIndexDouble(a() As Double, ByVal L As Long, ByVal r As Long) As Long
    ' Jon L. Bentley and M. Douglas McILroy, Engineering a Sort Function
    ' Software-Practice and Experience, vol. 23(11), 1249-1265 (November 1993)
    Dim pl As Long
    Dim pm As Long
    Dim pn As Long
    Dim m As Long
    Dim n As Long
    Dim s As Long
    
    n = r - L + 1
    m = n \ 2
    '   Small arrays, middle element
    pm = m
    If n > 7 Then
        '   Mid-size, median of 3
        pl = L
        pn = r
        If n > 40 Then
            '   Big arrays, pseudomedian of 9
            s = n \ 8
            pl = Med3IndexDouble(a(), pl, pl + s, pl + (2 * s))
            pm = Med3IndexDouble(a(), pm - s, pm, pm + s)
            pn = Med3IndexDouble(a(), pn - (2 * s), pn - s, pn)
        End If
        pm = Med3IndexDouble(a(), pl, pm, pn)
    End If
    GetMedianIndexDouble = pm
End Function

Private Function Med3IndexDouble(D() As Double, a As Long, b As Long, c As Long) As Long
    Dim med As Long
    If D(a) < D(b) Then
        If D(b) < D(c) Then
            med = b
        Else
            If D(a) < D(c) Then
                med = c
            Else
                med = a
            End If
        End If
    Else
        If D(b) > D(c) Then
            med = b
        Else
            If D(a) > D(c) Then
                med = c
            Else
                med = a
            End If
        End If
    End If
    Med3IndexDouble = med
End Function

Private Function GetMedianIndexString(a() As String, ByVal L As Long, ByVal r As Long) As Long
    ' Jon L. Bentley and M. Douglas McILroy, Engineering a Sort Function
    ' Software-Practice and Experience, vol. 23(11), 1249-1265 (November 1993)
    Dim pl As Long
    Dim pm As Long
    Dim pn As Long
    Dim m As Long
    Dim n As Long
    Dim s As Long
    
    n = r - L + 1
    m = n \ 2
    '   Small arrays, middle element
    pm = m
    If n > 7 Then
        '   Mid-size, median of 3
        pl = L
        pn = r
        If n > 40 Then
            '   Big arrays, pseudomedian of 9
            s = n \ 8
            pl = Med3IndexString(a(), pl, pl + s, pl + (2 * s))
            pm = Med3IndexString(a(), pm - s, pm, pm + s)
            pn = Med3IndexString(a(), pn - (2 * s), pn - s, pn)
        End If
        pm = Med3IndexString(a(), pl, pm, pn)
    End If
    GetMedianIndexString = pm
End Function

Private Function Med3IndexString(D() As String, a As Long, b As Long, c As Long) As Long
    Dim med As Long
    If D(a) < D(b) Then
        If D(b) < D(c) Then
            med = b
        Else
            If D(a) < D(c) Then
                med = c
            Else
                med = a
            End If
        End If
    Else
        If D(b) > D(c) Then
            med = b
        Else
            If D(a) > D(c) Then
                med = c
            Else
                med = a
            End If
        End If
    End If
    Med3IndexString = med
End Function

Private Function pGetMedianIndexDouble(a() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long) As Long
    ' Jon L. Bentley and M. Douglas McILroy, Engineering a Sort Function
    ' Software-Practice and Experience, vol. 23(11), 1249-1265 (November 1993)
    Dim pl As Long
    Dim pm As Long
    Dim pn As Long
    Dim m As Long
    Dim n As Long
    Dim s As Long
    
    n = r - L + 1
    m = n \ 2
    '   Small arrays, middle element
    pm = m
    If n > 7 Then
        '   Mid-size, median of 3
        pl = L
        pn = r
        If n > 40 Then
            '   Big arrays, pseudomedian of 9
            s = n \ 8
            pl = pMed3IndexDouble(a(), Ptr(), pl, pl + s, pl + (2 * s))
            pm = pMed3IndexDouble(a(), Ptr(), pm - s, pm, pm + s)
            pn = pMed3IndexDouble(a(), Ptr(), pn - (2 * s), pn - s, pn)
        End If
        pm = pMed3IndexDouble(a(), Ptr(), pl, pm, pn)
    End If
    pGetMedianIndexDouble = pm
End Function

Private Function pMed3IndexDouble(D() As Double, Ptr() As Long, a As Long, b As Long, c As Long) As Long
    Dim med As Long
    If D(Ptr(a)) < D(Ptr(b)) Then
        If D(Ptr(b)) < D(Ptr(c)) Then
            med = b
        Else
            If D(Ptr(a)) < D(Ptr(c)) Then
                med = c
            Else
                med = a
            End If
        End If
    Else
        If D(Ptr(b)) > D(Ptr(c)) Then
            med = b
        Else
            If D(Ptr(a)) > D(Ptr(c)) Then
                med = c
            Else
                med = a
            End If
        End If
    End If
    pMed3IndexDouble = med
End Function

Private Function pGetMedianIndexString(a() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long) As Long
    ' Jon L. Bentley and M. Douglas McILroy, Engineering a Sort Function
    ' Software-Practice and Experience, vol. 23(11), 1249-1265 (November 1993)
    Dim pl As Long
    Dim pm As Long
    Dim pn As Long
    Dim m As Long
    Dim n As Long
    Dim s As Long
    
    n = r - L + 1
    m = n \ 2
    '   Small arrays, middle element
    pm = m
    If n > 7 Then
        '   Mid-size, median of 3
        pl = L
        pn = r
        If n > 40 Then
            '   Big arrays, pseudomedian of 9
            s = n \ 8
            pl = pMed3IndexString(a(), Ptr(), pl, pl + s, pl + (2 * s))
            pm = pMed3IndexString(a(), Ptr(), pm - s, pm, pm + s)
            pn = pMed3IndexString(a(), Ptr(), pn - (2 * s), pn - s, pn)
        End If
        pm = pMed3IndexString(a(), Ptr(), pl, pm, pn)
    End If
    pGetMedianIndexString = pm
End Function

Private Function pMed3IndexString(D() As String, Ptr() As Long, a As Long, b As Long, c As Long) As Long
    Dim med As Long
    If D(Ptr(a)) < D(Ptr(b)) Then
        If D(Ptr(b)) < D(Ptr(c)) Then
            med = b
        Else
            If D(Ptr(a)) < D(Ptr(c)) Then
                med = c
            Else
                med = a
            End If
        End If
    Else
        If D(Ptr(b)) > D(Ptr(c)) Then
            med = b
        Else
            If D(Ptr(a)) > D(Ptr(c)) Then
                med = c
            Else
                med = a
            End If
        End If
    End If
    pMed3IndexString = med
End Function

