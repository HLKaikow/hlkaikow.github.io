Attribute VB_Name = "modSortKB"
' Copyright � 2003-2004 by Howard Kaikow. All rights reserved.
' Author URL: http://www.standards.com/
' Author email address: kaikow@standards.com
' Date: 7 January 2004

' In this class, each algorithm, call it XXX, is implemented using 5 variations: XXXLong, XXXDouble, XXXString,
' pXXXDouble and pXXXString, where the pXXX use pointers, instead of a direct manipulation of the data.

' The algorithms in this class are based on the code in from Microsoft KB article Q169617, dated 29 April 2001 and
' were modified by Howard Kaikow as follows:
'       1. Removed code for testing timing.
'       2. Renamed procedures
'       3. The code in the article uses the Variant data type. The code in this class uses a
'          separate procedure for each data type, and adds the poiner variations of each algorithm.
Option Explicit

Public Sub pBubbleDouble(iArray() As Double, lngP() As Long)
  Dim lLoop1 As Long
  Dim lLoop2 As Long
  Dim lTemp As Long
  
  For lLoop1 = UBound(iArray) To LBound(iArray) Step -1
    For lLoop2 = LBound(iArray) + 1 To lLoop1
      If iArray(lngP(lLoop2 - 1)) > iArray(lngP(lLoop2)) Then
        lTemp = lngP(lLoop2 - 1)
        lngP(lLoop2 - 1) = lngP(lLoop2)
        lngP(lLoop2) = lTemp
      End If
    Next lLoop2
  Next lLoop1
End Sub

Public Sub pBubbleString(iArray() As String, lngP() As Long)
  Dim lLoop1 As Long
  Dim lLoop2 As Long
  Dim lTemp As Long
  
  For lLoop1 = UBound(iArray) To LBound(iArray) Step -1
    For lLoop2 = LBound(iArray) + 1 To lLoop1
      If iArray(lngP(lLoop2 - 1)) > iArray(lngP(lLoop2)) Then
        lTemp = lngP(lLoop2 - 1)
        lngP(lLoop2 - 1) = lngP(lLoop2)
        lngP(lLoop2) = lTemp
      End If
    Next lLoop2
  Next lLoop1
End Sub

Public Sub BubbleDouble(iArray() As Double)
  Dim lLoop1 As Long
  Dim lLoop2 As Long
  Dim lTemp As Double
  
  For lLoop1 = UBound(iArray) To LBound(iArray) Step -1
    For lLoop2 = LBound(iArray) + 1 To lLoop1
      If iArray(lLoop2 - 1) > iArray(lLoop2) Then
        lTemp = iArray(lLoop2 - 1)
        iArray(lLoop2 - 1) = iArray(lLoop2)
        iArray(lLoop2) = lTemp
      End If
    Next lLoop2
  Next lLoop1
End Sub

Public Sub BubbleLong(iArray() As Long)
  Dim lLoop1 As Long
  Dim lLoop2 As Long
  Dim lTemp As Long
  
  For lLoop1 = UBound(iArray) To LBound(iArray) Step -1
    For lLoop2 = LBound(iArray) + 1 To lLoop1
      If iArray(lLoop2 - 1) > iArray(lLoop2) Then
        lTemp = iArray(lLoop2 - 1)
        iArray(lLoop2 - 1) = iArray(lLoop2)
        iArray(lLoop2) = lTemp
      End If
    Next lLoop2
  Next lLoop1
End Sub

Public Sub BubbleString(iArray() As String)
  Dim lLoop1 As Long
  Dim lLoop2 As Long
  Dim lTemp As String
  
  For lLoop1 = UBound(iArray) To LBound(iArray) Step -1
    For lLoop2 = LBound(iArray) + 1 To lLoop1
      If iArray(lLoop2 - 1) > iArray(lLoop2) Then
        lTemp = iArray(lLoop2 - 1)
        iArray(lLoop2 - 1) = iArray(lLoop2)
        iArray(lLoop2) = lTemp
      End If
    Next lLoop2
  Next lLoop1
End Sub

Public Sub ShellDouble(vArray() As Double)
  Dim lLoop1 As Long
  Dim lHold As Long
  Dim lHValue As Long
  Dim lTemp As Double

  lHValue = 1
  Do
    lHValue = 3 * lHValue + 1
  Loop Until lHValue > UBound(vArray)
  Do
    lHValue = lHValue / 3
    For lLoop1 = lHValue + LBound(vArray) To UBound(vArray)
      lTemp = vArray(lLoop1)
      lHold = lLoop1
      Do While vArray(lHold - lHValue) > lTemp
        vArray(lHold) = vArray(lHold - lHValue)
        lHold = lHold - lHValue
        If lHold < lHValue Then Exit Do
      Loop
      vArray(lHold) = lTemp
    Next lLoop1
  Loop Until lHValue = LBound(vArray)
End Sub

Public Sub ShellLong(vArray() As Long)
  Dim lLoop1 As Long
  Dim lHold As Long
  Dim lHValue As Long
  Dim lTemp As Long

  lHValue = 1
  Do
    lHValue = 3 * lHValue + 1
  Loop Until lHValue > UBound(vArray)
  Do
    lHValue = lHValue / 3
    For lLoop1 = lHValue + LBound(vArray) To UBound(vArray)
      lTemp = vArray(lLoop1)
      lHold = lLoop1
      Do While vArray(lHold - lHValue) > lTemp
        vArray(lHold) = vArray(lHold - lHValue)
        lHold = lHold - lHValue
        If lHold < lHValue Then Exit Do
      Loop
      vArray(lHold) = lTemp
    Next lLoop1
  Loop Until lHValue = LBound(vArray)
End Sub

Public Sub ShellString(vArray() As String)
  Dim lLoop1 As Long
  Dim lHold As Long
  Dim lHValue As Long
  Dim lTemp As String

  lHValue = 1
  Do
    lHValue = 3 * lHValue + 1
  Loop Until lHValue > UBound(vArray)
  Do
    lHValue = lHValue / 3
    For lLoop1 = lHValue + LBound(vArray) To UBound(vArray)
      lTemp = vArray(lLoop1)
      lHold = lLoop1
      Do While vArray(lHold - lHValue) > lTemp
        vArray(lHold) = vArray(lHold - lHValue)
        lHold = lHold - lHValue
        If lHold < lHValue Then Exit Do
      Loop
      vArray(lHold) = lTemp
    Next lLoop1
  Loop Until lHValue = LBound(vArray)
End Sub

Public Sub pShellDouble(vArray() As Double, lngP() As Long)
  Dim lLoop1 As Long
  Dim lHold As Long
  Dim lHValue As Long
  Dim lTemp As Long

  lHValue = 1
  Do
    lHValue = 3 * lHValue + 1
  Loop Until lHValue > UBound(vArray)
  Do
    lHValue = lHValue / 3
    For lLoop1 = lHValue + LBound(vArray) To UBound(vArray)
      lTemp = lngP(lLoop1)
      lHold = lLoop1
      Do While vArray(lngP(lHold - lHValue)) > vArray(lTemp)
        lngP(lHold) = lngP(lHold - lHValue)
        lHold = lHold - lHValue
        If lHold < lHValue Then Exit Do
      Loop
      lngP(lHold) = lTemp
    Next lLoop1
  Loop Until lHValue = LBound(vArray)
End Sub

Public Sub pShellString(vArray() As String, lngP() As Long)
  Dim lLoop1 As Long
  Dim lHold As Long
  Dim lHValue As Long
  Dim lTemp As Long

  lHValue = 1
  Do
    lHValue = 3 * lHValue + 1
  Loop Until lHValue > UBound(vArray)
  Do
    lHValue = lHValue / 3
    For lLoop1 = lHValue + LBound(vArray) To UBound(vArray)
      lTemp = lngP(lLoop1)
      lHold = lLoop1
      Do While vArray(lngP(lHold - lHValue)) > vArray(lTemp)
        lngP(lHold) = lngP(lHold - lHValue)
        lHold = lHold - lHValue
        If lHold < lHValue Then Exit Do
      Loop
      lngP(lHold) = lTemp
    Next lLoop1
  Loop Until lHValue = LBound(vArray)
End Sub
