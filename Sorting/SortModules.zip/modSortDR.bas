Attribute VB_Name = "modSortDR"
#Const blnDR = True ' Also needed in clsSortDR, etc.
#If blnDR Then
    ' Copyright � 2003-2004 by Howard Kaikow. All rights reserved.
    ' Author URL: http://www.standards.com/
    ' Author email address: kaikow@standards.com
    ' Date: 8 January 2004

    ' In this class, each algorithm, call it XXX, is implemented using 5 variations: XXXL, XXXD,
    ' XXXS, pXXXD and pXXXS, where the pXXX use pointers, instead of a direct manipulation
    ' of the data.
    
    ' The XXXL, pXXXD and pXXXS variations were created by David Ring.
    ' The XXXD and XXXS variations were created by Howard Kaikow.
    
    Option Explicit
        
    Public Sub InsertS(a() As String, lo&, hi&)
        Dim L&, r&, KEY As String, tmp As String
        
        For r = lo + 1 To hi
            KEY = a(r)
            For L = r To lo + 1 Step -1
                tmp = a(L - 1)
                If KEY < tmp Then a(L) = tmp Else Exit For
            Next L
            a(L) = KEY
        Next r
    End Sub
    
    Public Sub InsertD(a() As Double, lo&, hi&)
        Dim L&, r&, KEY As Double, tmp As Double
        
        For r = lo + 1 To hi
            KEY = a(r)
            For L = r To lo + 1 Step -1
                tmp = a(L - 1)
                If KEY < tmp Then a(L) = tmp Else Exit For
            Next L
            a(L) = KEY
        Next r
    End Sub
    
    Public Sub InsertL(a&(), lo&, hi&)
        Dim L&, r&, KEY&, tmp&
        
        For r = lo + 1 To hi
            KEY = a(r)
            For L = r To lo + 1 Step -1
                tmp = a(L - 1)
                If KEY < tmp Then a(L) = tmp Else Exit For
            Next L
            a(L) = KEY
        Next r
    End Sub
    
    Public Sub pInsertD(a#(), p&(), lo&, hi&)
        Dim L&, r&, TMP1&, TMP2&, KEY#
            
        For r = lo + 1 To hi
            TMP1 = p(r): KEY = a(TMP1)
            For L = r To lo + 1 Step -1
                TMP2 = p(L - 1)
                If KEY < a(TMP2) Then p(L) = TMP2 Else Exit For
            Next L
            p(L) = TMP1
        Next r
    End Sub
    
    Public Sub pInsertS(a$(), p&(), lo&, hi&)
        Dim L&, r&, TMP1&, TMP2&, KEY$
        
        For r = lo + 1 To hi
            TMP1 = p(r): KEY = a(TMP1)
            For L = r To lo + 1 Step -1
                TMP2 = p(L - 1)
                If KEY < a(TMP2) Then p(L) = TMP2 Else Exit For
            Next L
            p(L) = TMP1
        Next r
    End Sub
    
   Public Sub SelectL(a&(), lo&, hi&)
        Dim LP&, RP&, i&, pLO&, pHI&, LOVAL&, HIVAL&, KEY&
        
        LP = lo: RP = hi
        While LP < RP
            pLO = LP: pHI = RP
            LOVAL = a(pLO): HIVAL = a(pHI)
            For i = LP To RP
                KEY = a(i)
                If KEY < LOVAL Then
                    pLO = i: LOVAL = KEY
                ElseIf KEY > HIVAL Then
                    pHI = i: HIVAL = KEY
                End If
            Next i
            If pLO = RP Then
                If pHI = LP Then
                    i = a(LP): a(LP) = a(RP): a(RP) = i
                Else
                    i = a(LP): a(LP) = a(pLO): a(pLO) = i
                    i = a(RP): a(RP) = a(pHI): a(pHI) = i
                End If
            Else
                i = a(RP): a(RP) = a(pHI): a(pHI) = i
                i = a(LP): a(LP) = a(pLO): a(pLO) = i
            End If
            LP = LP + 1: RP = RP - 1
        Wend
    End Sub
    
   Public Sub SelectD(a() As Double, lo&, hi&)
        Dim LP&, RP&, i&, pLO&, pHI&, LOVAL As Double, HIVAL As Double, KEY As Double
        Dim dblTemp As Double
        
        LP = lo: RP = hi
        While LP < RP
            pLO = LP: pHI = RP
            LOVAL = a(pLO): HIVAL = a(pHI)
            For i = LP To RP
                KEY = a(i)
                If KEY < LOVAL Then
                    pLO = i: LOVAL = KEY
                ElseIf KEY > HIVAL Then
                    pHI = i: HIVAL = KEY
                End If
            Next i
            If pLO = RP Then
                If pHI = LP Then
                    dblTemp = a(LP): a(LP) = a(RP): a(RP) = dblTemp
                Else
                    dblTemp = a(LP): a(LP) = a(pLO): a(pLO) = dblTemp
                    dblTemp = a(RP): a(RP) = a(pHI): a(pHI) = dblTemp
                End If
            Else
                dblTemp = a(RP): a(RP) = a(pHI): a(pHI) = dblTemp
                dblTemp = a(LP): a(LP) = a(pLO): a(pLO) = dblTemp
            End If
            LP = LP + 1: RP = RP - 1
        Wend
    End Sub
    
   Public Sub SelectS(a() As String, lo&, hi&)
        Dim LP&, RP&, i&, pLO&, pHI&, LOVAL As String, HIVAL As String, KEY As String
        Dim strTemp As String
        
        LP = lo: RP = hi
        While LP < RP
            pLO = LP: pHI = RP
            LOVAL = a(pLO): HIVAL = a(pHI)
            For i = LP To RP
                KEY = a(i)
                If KEY < LOVAL Then
                    pLO = i: LOVAL = KEY
                ElseIf KEY > HIVAL Then
                    pHI = i: HIVAL = KEY
                End If
            Next i
            If pLO = RP Then
                If pHI = LP Then
                    strTemp = a(LP): a(LP) = a(RP): a(RP) = strTemp
                Else
                    strTemp = a(LP): a(LP) = a(pLO): a(pLO) = strTemp
                    strTemp = a(RP): a(RP) = a(pHI): a(pHI) = strTemp
                End If
            Else
                strTemp = a(RP): a(RP) = a(pHI): a(pHI) = strTemp
                strTemp = a(LP): a(LP) = a(pLO): a(pLO) = strTemp
            End If
            LP = LP + 1: RP = RP - 1
        Wend
    End Sub
    
    Public Sub pSelectD(a#(), p&(), lo&, hi&)
        Dim LP&, RP&, i&, pLO&, pHI&, LOVAL#, HIVAL#, KEY#
        
        LP = lo: RP = hi
        While LP < RP
            pLO = LP: pHI = RP
            LOVAL = a(p(LP)): HIVAL = a(p(RP))
            For i = LP To RP
                KEY = a(p(i))
                If KEY < LOVAL Then
                    pLO = i: LOVAL = KEY
                ElseIf KEY > HIVAL Then
                    pHI = i: HIVAL = KEY
                End If
            Next i
            If pLO = RP Then
                If pHI = LP Then
                    i = p(LP): p(LP) = p(RP): p(RP) = i
                Else
                    i = p(LP): p(LP) = p(pLO): p(pLO) = i
                    i = p(RP): p(RP) = p(pHI): p(pHI) = i
                End If
            Else
                i = p(RP): p(RP) = p(pHI): p(pHI) = i
                i = p(LP): p(LP) = p(pLO): p(pLO) = i
            End If
            LP = LP + 1: RP = RP - 1
        Wend
    End Sub
    
    Public Sub pSelectS(a$(), p&(), lo&, hi&)
        Dim LP&, RP&, i&, pLO&, pHI&, LOVAL$, HIVAL$, KEY$
        
        LP = lo: RP = hi
        While LP < RP
            pLO = LP: pHI = RP
            LOVAL = a(p(LP)): HIVAL = a(p(RP))
            For i = LP To RP
                KEY = a(p(i))
                If KEY < LOVAL Then
                    pLO = i: LOVAL = KEY
                ElseIf KEY > HIVAL Then
                    pHI = i: HIVAL = KEY
                End If
            Next i
            If pLO = RP Then
                If pHI = LP Then
                    i = p(LP): p(LP) = p(RP): p(RP) = i
                Else
                    i = p(LP): p(LP) = p(pLO): p(pLO) = i
                    i = p(RP): p(RP) = p(pHI): p(pHI) = i
                End If
            Else
                i = p(RP): p(RP) = p(pHI): p(pHI) = i
                i = p(LP): p(LP) = p(pLO): p(pLO) = i
            End If
            LP = LP + 1: RP = RP - 1
        Wend
    End Sub
          
    Public Sub ShellL(a&(), lo&, hi&)
        Dim GAP&, LP&, RP&, KEY&, POS&, KEY2&
        
        GAP = 1
        While GAP * 3 < hi - lo: GAP = GAP * 3 + 1: Wend
        While GAP > 2
            For RP = GAP + 1 To hi
                KEY = a(RP): POS = RP
                Do While POS > GAP
                    LP = POS - GAP: KEY2 = a(LP)
                    If KEY2 <= KEY Then Exit Do
                    a(POS) = KEY2: POS = LP
                Loop
                a(POS) = KEY
            Next RP
            GAP = GAP / 3
        Wend
        InsertL a, lo, hi
    End Sub
    
    Public Sub ShellS(a() As String, lo&, hi&)
        Dim GAP&, LP&, RP&, KEY As String, POS&, KEY2 As String
        
        GAP = 1
        While GAP * 3 < hi - lo: GAP = GAP * 3 + 1: Wend
        While GAP > 2
            For RP = GAP + 1 To hi
                KEY = a(RP): POS = RP
                Do While POS > GAP
                    LP = POS - GAP: KEY2 = a(LP)
                    If KEY2 <= KEY Then Exit Do
                    a(POS) = KEY2: POS = LP
                Loop
                a(POS) = KEY
            Next RP
            GAP = GAP / 3
        Wend
        InsertS a, lo, hi
    End Sub
    
    Public Sub ShellD(a() As Double, lo&, hi&)
        Dim GAP&, LP&, RP&, KEY As Double, POS&, KEY2 As Double
        
        GAP = 1
        While GAP * 3 < hi - lo: GAP = GAP * 3 + 1: Wend
        While GAP > 2
            For RP = GAP + 1 To hi
                KEY = a(RP): POS = RP
                Do While POS > GAP
                    LP = POS - GAP: KEY2 = a(LP)
                    If KEY2 <= KEY Then Exit Do
                    a(POS) = KEY2: POS = LP
                Loop
                a(POS) = KEY
            Next RP
            GAP = GAP / 3
        Wend
        InsertD a, lo, hi
    End Sub
    
    Public Sub pShellD(a#(), p&(), lo&, hi&)
        Dim GAP&, LP&, RP&, KEY#, POS&, TP&, TP2&
        
        GAP = 1
        While GAP * 3 < hi - lo: GAP = GAP * 3 + 1: Wend
        While GAP > 2
            For RP = GAP + 1 To hi
                TP = p(RP): KEY = a(TP): POS = RP
                Do While POS > GAP
                    LP = POS - GAP: TP2 = p(LP)
                    If a(TP2) <= KEY Then Exit Do
                    p(POS) = TP2: POS = LP
                Loop
                p(POS) = TP
            Next RP
            GAP = GAP / 3
        Wend
        pInsertD a, p, lo, hi
    End Sub
    
    Public Sub pShellS(a$(), p&(), lo&, hi&)
        Dim GAP&, LP&, RP&, KEY$, POS&, TP&, TP2&
        
        GAP = 1
        While GAP * 3 < hi - lo: GAP = GAP * 3 + 1: Wend
        While GAP > 2
            For RP = GAP + 1 To hi
                TP = p(RP): KEY = a(TP): POS = RP
                Do While POS > GAP
                    LP = POS - GAP: TP2 = p(LP)
                    If a(TP2) <= KEY Then Exit Do
                    p(POS) = TP2: POS = LP
                Loop
                p(POS) = TP
            Next RP
            GAP = GAP / 3
        Wend
        pInsertS a, p, lo, hi
    End Sub
    
    Public Sub HeapL(a&(), lo&, hi&)
        Dim POS&, NODE&, LEAF&, KEY&
        
        For POS = (hi + lo) \ 2 To lo Step -1
            NODE = POS: KEY = a(NODE)
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > hi Then Exit Do
                If LEAF < hi Then If a(LEAF + 1) > a(LEAF) Then LEAF = LEAF + 1
                If KEY > a(LEAF) Then Exit Do
                a(NODE) = a(LEAF): NODE = LEAF
            Loop
            a(NODE) = KEY
        Next POS
        POS = hi
        While POS > lo
            KEY = a(POS): a(POS) = a(lo): NODE = lo: POS = POS - 1
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > POS Then Exit Do
                If LEAF < POS Then If a(LEAF + 1) > a(LEAF) Then LEAF = LEAF + 1
                If KEY > a(LEAF) Then Exit Do
                a(NODE) = a(LEAF): NODE = LEAF
            Loop
            a(NODE) = KEY
        Wend
    End Sub
    
    Public Sub HeapS(a() As String, lo&, hi&)
        Dim POS&, NODE&, LEAF&, KEY As String
        
        For POS = (hi + lo) \ 2 To lo Step -1
            NODE = POS: KEY = a(NODE)
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > hi Then Exit Do
                If LEAF < hi Then If a(LEAF + 1) > a(LEAF) Then LEAF = LEAF + 1
                If KEY > a(LEAF) Then Exit Do
                a(NODE) = a(LEAF): NODE = LEAF
            Loop
            a(NODE) = KEY
        Next POS
        POS = hi
        While POS > lo
            KEY = a(POS): a(POS) = a(lo): NODE = lo: POS = POS - 1
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > POS Then Exit Do
                If LEAF < POS Then If a(LEAF + 1) > a(LEAF) Then LEAF = LEAF + 1
                If KEY > a(LEAF) Then Exit Do
                a(NODE) = a(LEAF): NODE = LEAF
            Loop
            a(NODE) = KEY
        Wend
    End Sub
    
    Public Sub HeapD(a() As Double, lo&, hi&)
        Dim POS&, NODE&, LEAF&, KEY As Double
        
        For POS = (hi + lo) \ 2 To lo Step -1
            NODE = POS: KEY = a(NODE)
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > hi Then Exit Do
                If LEAF < hi Then If a(LEAF + 1) > a(LEAF) Then LEAF = LEAF + 1
                If KEY > a(LEAF) Then Exit Do
                a(NODE) = a(LEAF): NODE = LEAF
            Loop
            a(NODE) = KEY
        Next POS
        POS = hi
        While POS > lo
            KEY = a(POS): a(POS) = a(lo): NODE = lo: POS = POS - 1
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > POS Then Exit Do
                If LEAF < POS Then If a(LEAF + 1) > a(LEAF) Then LEAF = LEAF + 1
                If KEY > a(LEAF) Then Exit Do
                a(NODE) = a(LEAF): NODE = LEAF
            Loop
            a(NODE) = KEY
        Wend
    End Sub
    
    Public Sub pHeapD(a#(), p&(), lo&, hi&)
        Dim POS&, NODE&, LEAF&, KEY#, TP&
        
        For POS = (hi + lo) \ 2 To lo Step -1
            NODE = POS: TP = p(NODE): KEY = a(TP)
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > hi Then Exit Do
                If LEAF < hi Then If a(p(LEAF + 1)) > a(p(LEAF)) Then LEAF = LEAF + 1
                If KEY > a(p(LEAF)) Then Exit Do
                p(NODE) = p(LEAF): NODE = LEAF
            Loop
            p(NODE) = TP
        Next POS
        POS = hi
        While POS > lo
            TP = p(POS): KEY = a(TP): p(POS) = p(lo): NODE = lo: POS = POS - 1
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > POS Then Exit Do
                If LEAF < POS Then If a(p(LEAF + 1)) > a(p(LEAF)) Then LEAF = LEAF + 1
                If KEY > a(p(LEAF)) Then Exit Do
                p(NODE) = p(LEAF): NODE = LEAF
            Loop
            p(NODE) = TP
        Wend
    End Sub
    
    Public Sub pHeapS(a$(), p&(), lo&, hi&)
        Dim POS&, NODE&, LEAF&, KEY$, TP&
        
        For POS = (hi + lo) \ 2 To lo Step -1
            NODE = POS: TP = p(NODE): KEY = a(TP)
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > hi Then Exit Do
                If LEAF < hi Then If a(p(LEAF + 1)) > a(p(LEAF)) Then LEAF = LEAF + 1
                If KEY > a(p(LEAF)) Then Exit Do
                p(NODE) = p(LEAF): NODE = LEAF
            Loop
            p(NODE) = TP
        Next POS
        POS = hi
        While POS > lo
            TP = p(POS): KEY = a(TP): p(POS) = p(lo): NODE = lo: POS = POS - 1
            Do
                LEAF = NODE + NODE + 1 - lo
                If LEAF > POS Then Exit Do
                If LEAF < POS Then If a(p(LEAF + 1)) > a(p(LEAF)) Then LEAF = LEAF + 1
                If KEY > a(p(LEAF)) Then Exit Do
                p(NODE) = p(LEAF): NODE = LEAF
            Loop
            p(NODE) = TP
        Wend
    End Sub
            
    Public Sub MergeD(a() As Double, b() As Double, lo&, hi&)
        Dim rLN#, nR&, D#, i&, L&, r&, LP&, RP&, V1 As Double, V2 As Double, OP&
            
        rLN = 1 + hi - lo: nR = 1: D = lo
        While rLN > 24: nR = nR * 4: rLN = rLN / 4: Wend
        For i = 0 To nR - 1
            L = D: D = D + rLN: r = CLng(D) - 1
            For RP = L + 1 To r
                V1 = a(RP)
                For LP = RP To L + 1 Step -1
                    V2 = a(LP - 1)
                    If V1 < V2 Then a(LP) = V2 Else Exit For
                Next LP
                a(LP) = V1
            Next RP
        Next i
        While nR > 1
            D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If a(LP) <= a(RP) Then
                        b(OP) = a(LP): LP = LP + 1: OP = OP + 1
                        If LP > L Then
                            Do: b(OP) = a(RP): RP = RP + 1: OP = OP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        b(OP) = a(RP): RP = RP + 1: OP = OP + 1
                        If RP > r Then
                            Do: b(OP) = a(LP): LP = LP + 1: OP = OP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            nR = nR \ 2: rLN = rLN * 2: D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If b(LP) <= b(RP) Then
                        a(OP) = b(LP): OP = OP + 1: LP = LP + 1
                        If LP > L Then
                            Do: a(OP) = b(RP): OP = OP + 1: RP = RP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        a(OP) = b(RP): OP = OP + 1: RP = RP + 1
                        If RP > r Then
                            Do: a(OP) = b(LP): OP = OP + 1: LP = LP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            rLN = rLN * 2: nR = nR \ 2
        Wend
    End Sub
    
    Public Sub MergeS(a() As String, b() As String, lo&, hi&)
        Dim rLN#, nR&, D#, i&, L&, r&, LP&, RP&, V1 As String, V2 As String, OP&
            
        rLN = 1 + hi - lo: nR = 1: D = lo
        While rLN > 24: nR = nR * 4: rLN = rLN / 4: Wend
        For i = 0 To nR - 1
            L = D: D = D + rLN: r = CLng(D) - 1
            For RP = L + 1 To r
                V1 = a(RP)
                For LP = RP To L + 1 Step -1
                    V2 = a(LP - 1)
                    If V1 < V2 Then a(LP) = V2 Else Exit For
                Next LP
                a(LP) = V1
            Next RP
        Next i
        While nR > 1
            D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If a(LP) <= a(RP) Then
                        b(OP) = a(LP): LP = LP + 1: OP = OP + 1
                        If LP > L Then
                            Do: b(OP) = a(RP): RP = RP + 1: OP = OP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        b(OP) = a(RP): RP = RP + 1: OP = OP + 1
                        If RP > r Then
                            Do: b(OP) = a(LP): LP = LP + 1: OP = OP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            nR = nR \ 2: rLN = rLN * 2: D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If b(LP) <= b(RP) Then
                        a(OP) = b(LP): OP = OP + 1: LP = LP + 1
                        If LP > L Then
                            Do: a(OP) = b(RP): OP = OP + 1: RP = RP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        a(OP) = b(RP): OP = OP + 1: RP = RP + 1
                        If RP > r Then
                            Do: a(OP) = b(LP): OP = OP + 1: LP = LP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            rLN = rLN * 2: nR = nR \ 2
        Wend
    End Sub
    
    Public Sub MergeL(a&(), b&(), lo&, hi&)
        Dim rLN#, nR&, D#, i&, L&, r&, LP&, RP&, V1&, V2&, OP&
            
        rLN = 1 + hi - lo: nR = 1: D = lo
        While rLN > 24: nR = nR * 4: rLN = rLN / 4: Wend
        For i = 0 To nR - 1
            L = D: D = D + rLN: r = CLng(D) - 1
            For RP = L + 1 To r
                V1 = a(RP)
                For LP = RP To L + 1 Step -1
                    V2 = a(LP - 1)
                    If V1 < V2 Then a(LP) = V2 Else Exit For
                Next LP
                a(LP) = V1
            Next RP
        Next i
        While nR > 1
            D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If a(LP) <= a(RP) Then
                        b(OP) = a(LP): LP = LP + 1: OP = OP + 1
                        If LP > L Then
                            Do: b(OP) = a(RP): RP = RP + 1: OP = OP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        b(OP) = a(RP): RP = RP + 1: OP = OP + 1
                        If RP > r Then
                            Do: b(OP) = a(LP): LP = LP + 1: OP = OP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            nR = nR \ 2: rLN = rLN * 2: D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If b(LP) <= b(RP) Then
                        a(OP) = b(LP): OP = OP + 1: LP = LP + 1
                        If LP > L Then
                            Do: a(OP) = b(RP): OP = OP + 1: RP = RP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        a(OP) = b(RP): OP = OP + 1: RP = RP + 1
                        If RP > r Then
                            Do: a(OP) = b(LP): OP = OP + 1: LP = LP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            rLN = rLN * 2: nR = nR \ 2
        Wend
    End Sub
    
    Public Sub pMergeD(a#(), p&(), q&(), lo&, hi&)
        Dim rLN#, nR&, D#, i&, L&, r&, LP&, RP&, v#, TP&, OP&
        
        nR = 1: rLN = 1 + hi - lo: D = lo
        While rLN > 24: rLN = rLN / 4: nR = nR * 4: Wend
        For i = 0 To nR - 1
            L = D: D = D + rLN: r = CLng(D) - 1
            For RP = L + 1 To r
                OP = p(RP): v = a(OP)
                For LP = RP To L + 1 Step -1
                    TP = p(LP - 1)
                    If v < a(TP) Then p(LP) = TP Else Exit For
                Next LP
                p(LP) = OP
            Next RP
        Next i
        While nR > 1
            D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If a(p(LP)) <= a(p(RP)) Then
                        q(OP) = p(LP): OP = OP + 1: LP = LP + 1
                        If LP > L Then
                            Do
                                q(OP) = p(RP): OP = OP + 1: RP = RP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        q(OP) = p(RP): OP = OP + 1: RP = RP + 1
                        If RP > r Then
                            Do
                                q(OP) = p(LP): OP = OP + 1: LP = LP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            rLN = rLN * 2: nR = nR \ 2: D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If a(q(LP)) <= a(q(RP)) Then
                        p(OP) = q(LP): OP = OP + 1: LP = LP + 1
                        If LP > L Then
                            Do
                                p(OP) = q(RP): OP = OP + 1: RP = RP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        p(OP) = q(RP): OP = OP + 1: RP = RP + 1
                        If RP > r Then
                            Do
                                p(OP) = q(LP): OP = OP + 1: LP = LP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            rLN = rLN * 2: nR = nR \ 2
        Wend
    End Sub
    
    Public Sub pMergeS(a$(), p&(), q&(), lo&, hi&)
        Dim rLN#, nR&, D#, i&, L&, r&, LP&, RP&, v$, OP&, TP&
        
        nR = 1: rLN = 1 + hi - lo: D = lo
        While rLN > 24: rLN = rLN / 4: nR = nR * 4: Wend
        For i = 0 To nR - 1
            L = D: D = D + rLN: r = CLng(D) - 1
            For RP = L + 1 To r
                OP = p(RP): v = a(OP)
                For LP = RP To L + 1 Step -1
                    TP = p(LP - 1)
                    If v < a(TP) Then p(LP) = TP Else Exit For
                Next LP
                p(LP) = OP
            Next RP
        Next i
        While nR > 1
            D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If a(p(LP)) <= a(p(RP)) Then
                        q(OP) = p(LP): OP = OP + 1: LP = LP + 1
                        If LP > L Then
                            Do: q(OP) = p(RP): OP = OP + 1: RP = RP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        q(OP) = p(RP): OP = OP + 1: RP = RP + 1
                        If RP > r Then
                            Do: q(OP) = p(LP): OP = OP + 1: LP = LP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            rLN = rLN * 2: nR = nR \ 2: D = lo
            For i = 2 To nR Step 2
                LP = D: OP = LP: D = D + rLN: RP = D: L = RP - 1
                D = D + rLN: r = CLng(D) - 1
                Do
                    If a(q(LP)) <= a(q(RP)) Then
                        p(OP) = q(LP): OP = OP + 1: LP = LP + 1
                        If LP > L Then
                            Do: p(OP) = q(RP): OP = OP + 1: RP = RP + 1
                            Loop Until RP > r: Exit Do
                        End If
                    Else
                        p(OP) = q(RP): OP = OP + 1: RP = RP + 1
                        If RP > r Then
                            Do: p(OP) = q(LP): OP = OP + 1: LP = LP + 1
                            Loop Until LP > L: Exit Do
                        End If
                    End If
                Loop
            Next i
            rLN = rLN * 2: nR = nR \ 2
        Wend
    End Sub
 #End If

