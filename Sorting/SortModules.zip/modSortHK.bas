Attribute VB_Name = "modSortHK"
' Copyright � 2003-2004 by Howard Kaikow. All rights reserved.
' Author URL: http://www.standards.com/
' Author email address: kaikow@standards.com
' Date: 21 February 2004

' In this class, each algorithm, call it XXX, is implemented using 5 variations: XXXLong, XXXDouble, XXXString,
' pXXXDouble and pXXXString, where the pXXX use pointers, instead of a direct manipulation of the data.

' The Counting algorithm does not have pointer variations.

' All code in this class was created by Howard Kaikow.
    
' Where known, the source for the algorithm description is described in the code.

Option Explicit
    Private Const QuickCutoff As Long = 15

Public Sub CountingLong(data() As Long, L As Long, r As Long)
    Dim counts() As Long
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim MaximumValue As Long
    Dim MinimumValue As Long
    Dim top As Long
    Dim value As Long
    
    MinimumValue = data(L)
    MaximumValue = MinimumValue
    For i = L To r
        value = data(i)
        If value < MinimumValue Then
            MinimumValue = value
        ElseIf value > MaximumValue Then
            MaximumValue = value
        End If
    Next i
    
    top = MaximumValue - MinimumValue
    ReDim counts(top)
    
    For i = L To top
        counts(i) = 0
    Next i
    
    For i = L To r
        k = data(i) - MinimumValue
        counts(k) = counts(k) + 1
    Next i
    
    k = L
    For i = L To top
        value = i + MinimumValue
        For j = 1 To counts(i)
            data(k) = value
            k = k + 1
        Next j
    Next i
End Sub

Public Sub CountingDouble(data() As Double, L As Long, r As Long)
    Dim value As Double
    Dim k As Long
    Dim counts() As Long
    Dim i As Long
    Dim j As Long
    Dim MaximumValue As Long
    Dim MinimumValue As Long
    Dim top As Long
    
    MinimumValue = data(L)
    MaximumValue = MinimumValue
    For i = L To r
        value = data(i)
        If value < MinimumValue Then
            MinimumValue = value
        ElseIf value > MaximumValue Then
            MaximumValue = value
        End If
    Next i
    
    top = MaximumValue - MinimumValue
    ReDim counts(top)
    
    For i = L To top
        counts(i) = 0
    Next i
    
    For i = L To r
        k = data(i) - MinimumValue
        counts(k) = counts(k) + 1
    Next i
    
    k = L
    For i = L To top
        value = i + MinimumValue
        For j = 1 To counts(i)
            data(k) = value
            k = k + 1
        Next j
    Next i
End Sub

Public Sub CountingString(data() As String, L As Long, r As Long)
    Dim k As Long
    Dim counts() As Long
    Dim i As Long
    Dim j As Long
    Dim MaximumValue As Long
    Dim MinimumValue As Long
    Dim value As Long
    Dim top As Long
    Dim strValue As String
    
    MinimumValue = data(L)
    MaximumValue = MinimumValue
    For i = L To r
        value = CLng(data(i))
        If value < MinimumValue Then
            MinimumValue = data(i)
        ElseIf value > MaximumValue Then
            MaximumValue = value
        End If
    Next i
    
    top = MaximumValue - MinimumValue
    ReDim counts(top)
    
    For i = L To top
        counts(i) = 0
    Next i
    
    For i = L To r
        k = CLng(data(i)) - MinimumValue
        counts(k) = counts(k) + 1
    Next i
    
    k = L
    For i = L To top
        strValue = AlignNumberLong(i + MinimumValue)
        For j = 1 To counts(i)
            data(k) = strValue
            k = k + 1
        Next j
    Next i
End Sub

Public Sub InsertionLong(data() As Long, ByVal L As Long, ByVal r As Long)
    Dim i As Long
    Dim j As Long
    Dim temp As Long
    Dim value As Long
    
    For i = L + 1 To r
        temp = data(i)
        For j = i - 1 To L Step -1
            value = data(j)
            If value > temp Then
                data(j + 1) = value
            Else
                Exit For
            End If
        Next j
        data(j + 1) = temp
    Next i
End Sub

Public Sub InsertionDouble(data() As Double, ByVal L As Long, ByVal r As Long)
    Dim i As Long
    Dim j As Long
    Dim temp As Double
    Dim value As Double
    
    For i = L + 1 To r
        temp = data(i)
        For j = i - 1 To L Step -1
            value = data(j)
            If value > temp Then
                data(j + 1) = value
            Else
                Exit For
            End If
        Next j
        data(j + 1) = temp
    Next i
End Sub

Public Sub InsertionString(data() As String, ByVal L As Long, ByVal r As Long)
    Dim i As Long
    Dim j As Long
    Dim temp As String
    
    For i = L + 1 To r
        temp = data(i)
        For j = i - 1 To L Step -1
            If data(j) > temp Then
                data(j + 1) = data(j)
            Else
                Exit For
            End If
        Next j
        data(j + 1) = temp
    Next i
End Sub

Public Sub pInsertionDouble(data() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim temp As Double
    
    For i = L + 1 To r
        k = Ptr(i)
        temp = data(k)
        For j = i - 1 To L Step -1
            p = Ptr(j)
            If data(p) > temp Then
                Ptr(j + 1) = p
            Else
                Exit For
            End If
        Next j
        Ptr(j + 1) = k
    Next i
End Sub

Public Sub pInsertionString(data() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    Dim i As Long
    Dim j As Long
    Dim k As Long
    Dim p As Long
    Dim temp As String
    
    For i = L + 1 To r
        k = Ptr(i)
        temp = data(k)
        For j = i - 1 To L Step -1
            p = Ptr(j)
            If data(p) > temp Then
                Ptr(j + 1) = p
            Else
                Exit For
            End If
        Next j
        Ptr(j + 1) = k
    Next i
End Sub

Public Sub ShellLong(data() As Long, L As Long, r As Long)
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim temp As Long
    Dim value As Long
    
    h = r \ 2
    Do Until h = 0
        For i = h To r
            temp = data(i)
            For j = i - h To 0 Step -h
                value = data(j)
                If value > temp Then
                    data(j + h) = value
                Else
                    Exit For
                End If
            Next j
            data(j + h) = temp
        Next i
        h = h \ 2
    Loop
End Sub

Public Sub ShellDouble(data() As Double, L As Long, r As Long)
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim temp As Double
    Dim value As Double
    
    h = r \ 2
    Do Until h = 0
        For i = h To r
            temp = data(i)
            For j = i - h To 0 Step -h
                value = data(j)
                If value > temp Then
                    data(j + h) = value
                Else
                    Exit For
                End If
            Next j
            data(j + h) = temp
        Next i
        h = h \ 2
    Loop
End Sub

Public Sub ShellString(data() As String, L As Long, r As Long)
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim temp As String
    
    h = r \ 2
    Do Until h = 0
        For i = h To r
            temp = data(i)
            For j = i - h To 0 Step -h
                If data(j) > temp Then
                    data(j + h) = data(j)
                Else
                    Exit For
                End If
            Next j
            data(j + h) = temp
        Next i
        h = h \ 2
    Loop
End Sub

Public Sub pShellDouble(data() As Double, Ptr() As Long, L As Long, r As Long)
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim k As Long
    Dim p As Long
    Dim temp As Double
    
    h = r \ 2
    Do Until h = 0
        For i = h To r
            k = Ptr(i)
            temp = data(k)
            For j = i - h To 0 Step -h
                p = Ptr(j)
                If data(p) > temp Then
                    Ptr(j + h) = p
                Else
                    Exit For
                End If
            Next j
            Ptr(j + h) = k
        Next i
        h = h \ 2
    Loop
End Sub

Public Sub pShellString(data() As String, Ptr() As Long, L As Long, r As Long)
    Dim i As Long
    Dim j As Long
    Dim h As Long
    Dim k As Long
    Dim p As Long
    Dim temp As String
    
    h = r \ 2
    Do Until h = 0
        For i = h To r
            k = Ptr(i)
            temp = data(k)
            For j = i - h To 0 Step -h
                p = Ptr(j)
                If data(p) > temp Then
                    Ptr(j + h) = p
                Else
                    Exit For
                End If
            Next j
            Ptr(j + h) = k
        Next i
        h = h \ 2
    Loop
End Sub

Public Sub QuickLong(data() As Long, ByVal L As Long, ByVal r As Long)

    Dim high As Long
    Dim low As Long
    Dim pivot As Long
    Dim temp As Long

    If r - L < QuickCutoff Then
        InsertionLong data(), L, r
    Else
        pivot = data(Int((r - L + 1) * Rnd + L))
        low = L
        high = r
        Do
            Do While data(low) < pivot
                low = low + 1
            Loop
            Do While data(high) > pivot
                high = high - 1
            Loop
            If low <= high Then
                temp = data(high)
                data(high) = data(low)
                data(low) = temp
                low = low + 1
                high = high - 1
            End If
        Loop Until low > high
        
        If (high - L) < (r - low) Then
            QuickLong data(), L, high
            QuickLong data(), low, r
        Else
            QuickLong data(), low, r
            QuickLong data(), L, high
        End If
    End If
End Sub

Public Sub QuickDouble(data() As Double, ByVal L As Long, ByVal r As Long)

    Dim high As Long
    Dim low As Long
    Dim pivot As Double
    Dim temp As Double

    If r - L < QuickCutoff Then
        InsertionDouble data(), L, r
    Else
        pivot = data(Int((r - L + 1) * Rnd + L))
        low = L
        high = r
        Do
            Do While data(low) < pivot
                low = low + 1
            Loop
            Do While data(high) > pivot
                high = high - 1
            Loop
            If low <= high Then
                temp = data(high)
                data(high) = data(low)
                data(low) = temp
                low = low + 1
                high = high - 1
            End If
        Loop Until low > high
        
        If (high - L) < (r - low) Then
            QuickDouble data(), L, high
            QuickDouble data(), low, r
        Else
            QuickDouble data(), low, r
            QuickDouble data(), L, high
        End If
    End If
End Sub

Public Sub QuickString(data() As String, ByVal L As Long, ByVal r As Long)

    Dim high As Long
    Dim low As Long
    Dim pivot As String
    Dim temp As String

    If r - L < QuickCutoff Then
        InsertionString data(), L, r
    Else
        pivot = data(Int((r - L + 1) * Rnd + L))
        low = L
        high = r
        Do
            Do While data(low) < pivot
                low = low + 1
            Loop
            Do While data(high) > pivot
                high = high - 1
            Loop
            If low <= high Then
                temp = data(high)
                data(high) = data(low)
                data(low) = temp
                low = low + 1
                high = high - 1
            End If
        Loop Until low > high
        
        If (high - L) < (r - low) Then
            QuickString data(), L, high
            QuickString data(), low, r
        Else
            QuickString data(), low, r
            QuickString data(), L, high
        End If
    End If
End Sub

Public Sub pQuickDouble(data() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim pivot As Double
    Dim temp As Long

    If r - L < QuickCutoff Then
        pInsertionDouble data(), Ptr, L, r
    Else
        pivot = data(Ptr(Int((r - L + 1) * Rnd + L)))
        low = L
        high = r
        Do
            Do While data(Ptr(low)) < pivot
                low = low + 1
            Loop
            Do While data(Ptr(high)) > pivot
                high = high - 1
            Loop
            If low <= high Then
                temp = Ptr(high)
                Ptr(high) = Ptr(low)
                Ptr(low) = temp
                low = low + 1
                high = high - 1
            End If
        Loop Until low > high
        
        If (high - L) < (r - low) Then
            pQuickDouble data(), Ptr, L, high
            pQuickDouble data(), Ptr, low, r
        Else
            pQuickDouble data(), Ptr, low, r
            pQuickDouble data(), Ptr, L, high
        End If
    End If
End Sub

Public Sub pQuickString(data() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim pivot As String
    Dim temp As Long

    If r - L < QuickCutoff Then
        pInsertionString data(), Ptr, L, r
    Else
        pivot = data(Ptr(Int((r - L + 1) * Rnd + L)))
        low = L
        high = r
        Do
            Do While data(Ptr(low)) < pivot
                low = low + 1
            Loop
            Do While data(Ptr(high)) > pivot
                high = high - 1
            Loop
            If low <= high Then
                temp = Ptr(high)
                Ptr(high) = Ptr(low)
                Ptr(low) = temp
                low = low + 1
                high = high - 1
            End If
        Loop Until low > high
        
        If (high - L) < (r - low) Then
            pQuickString data(), Ptr, L, high
            pQuickString data(), Ptr, low, r
        Else
            pQuickString data(), Ptr, low, r
            pQuickString data(), Ptr, L, high
        End If
    End If
End Sub

Public Sub QuickModLong(data() As Long, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As Long
    Dim temp As Long

    Select Case r - L
        Case 0
        Case 1  ' Only 2 data items
            If data(L) > data(r) Then
                temp = data(r)
                data(r) = data(L)
                data(L) = temp
            End If
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
            If data(mid) > data(r) Then
                temp = data(mid)
                data(mid) = data(r)
                data(r) = temp
            End If
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
        Case Is < QuickCutoff
            InsertionLong data(), L, r
        Case Else
            low = L
            high = r
            pivot = data(Int((r - L + 1) * Rnd + L))
            Do
                Do While data(low) < pivot
                    low = low + 1
                Loop
                Do While data(high) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = data(high)
                    data(high) = data(low)
                    data(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                QuickModLong data(), L, high
                QuickModLong data(), low, r
            Else
                QuickModLong data(), low, r
                QuickModLong data(), L, high
            End If
    End Select
End Sub

Public Sub QuickModDouble(data() As Double, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As Double
    Dim temp As Double

    Select Case r - L
        Case 0
        Case 1  ' Only 2 data items
            If data(L) > data(r) Then
                temp = data(r)
                data(r) = data(L)
                data(L) = temp
            End If
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
            If data(mid) > data(r) Then
                temp = data(mid)
                data(mid) = data(r)
                data(r) = temp
            End If
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
        Case Is < QuickCutoff
            InsertionDouble data(), L, r
        Case Else
            low = L
            high = r
            pivot = data(Int((r - L + 1) * Rnd + L))
            Do
                Do While data(low) < pivot
                    low = low + 1
                Loop
                Do While data(high) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = data(high)
                    data(high) = data(low)
                    data(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                QuickModDouble data(), L, high
                QuickModDouble data(), low, r
            Else
                QuickModDouble data(), low, r
                QuickModDouble data(), L, high
            End If
    End Select
End Sub

Public Sub QuickModString(data() As String, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As String
    Dim temp As String

    Select Case r - L
        Case 0
        Case 1  ' Only 2 data items
            If data(L) > data(r) Then
                temp = data(r)
                data(r) = data(L)
                data(L) = temp
            End If
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
            If data(mid) > data(r) Then
                temp = data(mid)
                data(mid) = data(r)
                data(r) = temp
            End If
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
        Case Is < QuickCutoff
            InsertionString data(), L, r
        Case Else
            low = L
            high = r
            pivot = data(Int((r - L + 1) * Rnd + L))
            Do
                Do While StrComp(data(low), pivot) = -1
                    low = low + 1
                Loop
                Do While StrComp(data(high), pivot) = 1
                    high = high - 1
                Loop
                If low <= high Then
                    temp = data(high)
                    data(high) = data(low)
                    data(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                QuickModString data(), L, high
                QuickModString data(), low, r
            Else
                QuickModString data(), low, r
                QuickModString data(), L, high
            End If
    End Select
End Sub

Public Sub pQuickModDouble(data() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As Double
    Dim temp As Long

    Select Case r - L
        Case 0
        Case 1  ' Only 2 data items
            If data(Ptr(L)) > data(Ptr(r)) Then
                temp = Ptr(r)
                Ptr(r) = Ptr(L)
                Ptr(L) = temp
            End If
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(Ptr(mid)) < data(Ptr(L)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(L)
                Ptr(L) = temp
            End If
            If data(Ptr(mid)) > data(Ptr(r)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(r)
                Ptr(r) = temp
            End If
            If data(Ptr(mid)) < data(Ptr(L)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(L)
                Ptr(L) = temp
            End If
        Case Is < QuickCutoff
            pInsertionDouble data(), Ptr, L, r
        Case Else
            pivot = data(Ptr(Int((r - L + 1) * Rnd + L)))
            low = L
            high = r
            Do
                Do While data(Ptr(low)) < pivot
                    low = low + 1
                Loop
                Do While data(Ptr(high)) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = Ptr(high)
                    Ptr(high) = Ptr(low)
                    Ptr(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                pQuickModDouble data(), Ptr, L, high
                pQuickModDouble data(), Ptr, low, r
            Else
                pQuickModDouble data(), Ptr, low, r
                pQuickModDouble data(), Ptr, L, high
            End If
    End Select
End Sub

Public Sub pQuickModString(data() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As String
    Dim temp As Long

    Select Case r - L
        Case 0
        Case 1  ' Only 2 data items
            If data(Ptr(L)) > data(Ptr(r)) Then
                temp = Ptr(r)
                Ptr(r) = Ptr(L)
                Ptr(L) = temp
            End If
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(Ptr(mid)) < data(Ptr(L)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(L)
                Ptr(L) = temp
            End If
            If data(Ptr(mid)) > data(Ptr(r)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(r)
                Ptr(r) = temp
            End If
            If data(Ptr(mid)) < data(Ptr(L)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(L)
                Ptr(L) = temp
            End If
        Case Is < QuickCutoff
            pInsertionString data(), Ptr, L, r
        Case Else
            pivot = data(Ptr(Int((r - L + 1) * Rnd + L)))
            low = L
            high = r
            Do
                Do While data(Ptr(low)) < pivot
                    low = low + 1
                Loop
                Do While data(Ptr(high)) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = Ptr(high)
                    Ptr(high) = Ptr(low)
                    Ptr(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                pQuickModString data(), Ptr, L, high
                pQuickModString data(), Ptr, low, r
            Else
                pQuickModString data(), Ptr, low, r
                pQuickModString data(), Ptr, L, high
            End If
    End Select
End Sub

Public Sub QuickModModLong(data() As Long, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As Long
    Dim temp As Long

    Select Case r - L
        Case Is > QuickCutoff
            low = L
            high = r
            pivot = data(Int((r - L + 1) * Rnd + L))
            Do
                Do While data(low) < pivot
                    low = low + 1
                Loop
                Do While data(high) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = data(high)
                    data(high) = data(low)
                    data(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                QuickModModLong data(), L, high
                QuickModModLong data(), low, r
            Else
                QuickModModLong data(), low, r
                QuickModModLong data(), L, high
            End If
        Case Is > 2
            InsertionLong data(), L, r
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
            If data(mid) > data(r) Then
                temp = data(mid)
                data(mid) = data(r)
                data(r) = temp
            End If
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
        Case 1  ' Only 2 data items
            If data(L) > data(r) Then
                temp = data(r)
                data(r) = data(L)
                data(L) = temp
            End If
        Case 0
    End Select
End Sub

Public Sub QuickModModDouble(data() As Double, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As Double
    Dim temp As Double

    Select Case r - L
        Case Is > QuickCutoff
            low = L
            high = r
            pivot = data(Int((r - L + 1) * Rnd + L))
            Do
                Do While data(low) < pivot
                    low = low + 1
                Loop
                Do While data(high) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = data(high)
                    data(high) = data(low)
                    data(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                QuickModModDouble data(), L, high
                QuickModModDouble data(), low, r
            Else
                QuickModModDouble data(), low, r
                QuickModModDouble data(), L, high
            End If
        Case Is > 2
            InsertionDouble data(), L, r
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
            If data(mid) > data(r) Then
                temp = data(mid)
                data(mid) = data(r)
                data(r) = temp
            End If
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
        Case 1  ' Only 2 data items
            If data(L) > data(r) Then
                temp = data(r)
                data(r) = data(L)
                data(L) = temp
            End If
        Case 0
    End Select
End Sub

Public Sub QuickModModString(data() As String, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As String
    Dim temp As String

    Select Case r - L
        Case Is > QuickCutoff
            low = L
            high = r
            pivot = data(Int((r - L + 1) * Rnd + L))
            Do
                Do While data(low) < pivot
                    low = low + 1
                Loop
                Do While data(high) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = data(high)
                    data(high) = data(low)
                    data(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                QuickModModString data(), L, high
                QuickModModString data(), low, r
            Else
                QuickModModString data(), low, r
                QuickModModString data(), L, high
            End If
        Case Is > 2
            InsertionString data(), L, r
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
            If data(mid) > data(r) Then
                temp = data(mid)
                data(mid) = data(r)
                data(r) = temp
            End If
            If data(mid) < data(L) Then
                temp = data(mid)
                data(mid) = data(L)
                data(L) = temp
            End If
        Case 1  ' Only 2 data items
            If data(L) > data(r) Then
                temp = data(r)
                data(r) = data(L)
                data(L) = temp
            End If
        Case 0
    End Select
End Sub

Public Sub pQuickModModDouble(data() As Double, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As Double
    Dim temp As Long

    Select Case r - L
        Case Is > QuickCutoff
            pivot = data(Ptr(Int((r - L + 1) * Rnd + L)))
            low = L
            high = r
            Do
                Do While data(Ptr(low)) < pivot
                    low = low + 1
                Loop
                Do While data(Ptr(high)) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = Ptr(high)
                    Ptr(high) = Ptr(low)
                    Ptr(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                pQuickModModDouble data(), Ptr, L, high
                pQuickModModDouble data(), Ptr, low, r
            Else
                pQuickModModDouble data(), Ptr, low, r
                pQuickModModDouble data(), Ptr, L, high
            End If
        Case Is > 2
            pInsertionDouble data(), Ptr, L, r
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(Ptr(mid)) < data(Ptr(L)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(L)
                Ptr(L) = temp
            End If
            If data(Ptr(mid)) > data(Ptr(r)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(r)
                Ptr(r) = temp
            End If
            If data(Ptr(mid)) < data(Ptr(L)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(L)
                Ptr(L) = temp
            End If
        Case 1  ' Only 2 data items
            If data(Ptr(L)) > data(Ptr(r)) Then
                temp = Ptr(r)
                Ptr(r) = Ptr(L)
                Ptr(L) = temp
            End If
        Case 0
    End Select
End Sub

Public Sub pQuickModModString(data() As String, Ptr() As Long, ByVal L As Long, ByVal r As Long)
    Dim high As Long
    Dim low As Long
    Dim mid As Long
    Dim pivot As String
    Dim temp As Long

    Select Case r - L
        Case Is > QuickCutoff
            pivot = data(Ptr(Int((r - L + 1) * Rnd + L)))
            low = L
            high = r
            Do
                Do While data(Ptr(low)) < pivot
                    low = low + 1
                Loop
                Do While data(Ptr(high)) > pivot
                    high = high - 1
                Loop
                If low <= high Then
                    temp = Ptr(high)
                    Ptr(high) = Ptr(low)
                    Ptr(low) = temp
                    low = low + 1
                    high = high - 1
                End If
            Loop Until low > high
            
            If (high - L) < (r - low) Then
                pQuickModModString data(), Ptr, L, high
                pQuickModModString data(), Ptr, low, r
            Else
                pQuickModModString data(), Ptr, low, r
                pQuickModModString data(), Ptr, L, high
            End If
        Case Is > 2
            pInsertionString data(), Ptr, L, r
        Case 2  ' Only 3 data items
            mid = L + 1
            If data(Ptr(mid)) < data(Ptr(L)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(L)
                Ptr(L) = temp
            End If
            If data(Ptr(mid)) > data(Ptr(r)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(r)
                Ptr(r) = temp
            End If
            If data(Ptr(mid)) < data(Ptr(L)) Then
                temp = Ptr(mid)
                Ptr(mid) = Ptr(L)
                Ptr(L) = temp
            End If
        Case 1  ' Only 2 data items
            If data(Ptr(L)) > data(Ptr(r)) Then
                temp = Ptr(r)
                Ptr(r) = Ptr(L)
                Ptr(L) = temp
            End If
        Case 0
    End Select
End Sub
