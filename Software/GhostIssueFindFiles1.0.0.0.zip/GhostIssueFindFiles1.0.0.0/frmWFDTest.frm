VERSION 5.00
Begin VB.Form frmWFDTest 
   Caption         =   "List Files in  Path"
   ClientHeight    =   8040
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   12165
   LinkTopic       =   "Form1"
   ScaleHeight     =   8040
   ScaleWidth      =   12165
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtDriveLetter 
      Height          =   285
      Left            =   2040
      TabIndex        =   4
      Top             =   120
      Width           =   1455
   End
   Begin VB.TextBox txtProcessed 
      Height          =   285
      Left            =   5715
      Locked          =   -1  'True
      TabIndex        =   3
      Top             =   120
      Width           =   2055
   End
   Begin VB.ListBox lstStuff 
      Height          =   7275
      Left            =   120
      TabIndex        =   1
      Top             =   480
      Width           =   11895
   End
   Begin VB.CommandButton btnRunMe 
      Caption         =   "Run Me!"
      Height          =   315
      Left            =   10800
      TabIndex        =   0
      Top             =   120
      Width           =   1215
   End
   Begin VB.Label lblDriveLetter 
      Caption         =   "Drive Letter?"
      Height          =   255
      Left            =   120
      TabIndex        =   5
      Top             =   120
      Width           =   1815
   End
   Begin VB.Label lblProcessed 
      Caption         =   "Processing"
      Height          =   255
      Left            =   4395
      TabIndex        =   2
      Top             =   150
      Width           =   1095
   End
End
Attribute VB_Name = "frmWFDTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
    Private Declare Function FindClose Lib "kernel32" (ByVal hFindFile As Long) As Long
    Private Declare Function FindFirstFileW Lib "kernel32" _
        (ByVal lpFileName As Long, ByVal lpFindFileData As Long) As Long
    Private Declare Function FindNextFileW Lib "kernel32" _
        (ByVal hFindFile As Long, ByVal lpFindFileData As Long) As Long
    Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" _
        (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
    
    Private Type FILETIME
        dwLowDateTime  As Long
        dwHighDateTime As Long
    End Type
    
    Private Const ALTERNATE As Long = 14
    Private Const FILE_ATTRIBUTE_DIRECTORY As Long = &H10
    Private Const INVALID_HANDLE_VALUE As Long = -1
    Private Const MAX_PATH  As Long = 260
    Private Const LB_GETCOUNT As Long = &H18B
    Private Const LB_SETHORIZONTALEXTENT = &H194
    Private Const LB_SETTOPINDEX As Long = &H197
    
    ' Pass VarPtr(WFD) to W or simply WFD to A
    Private Type WIN32_FIND_DATA
        dwFileAttributes As Long
        ftCreationTime   As FILETIME
        ftLastAccessTime As FILETIME
        ftLastWriteTime  As FILETIME
        nFileSizeHigh    As Long
        nFileSizeLow     As Long
        dwReserved0      As Long
        dwReserved1      As Long
        cFileName        As String * MAX_PATH
        cAlternate       As String * ALTERNATE
    End Type
    
Private Sub Form_Activate()
    With lstStuff
        SendMessage .hwnd, LB_SETHORIZONTALEXTENT, _
            ScaleX(.Width, vbTwips, vbPixels) + 5000, ByVal 0&
    End With
End Sub

Private Sub btnRunMe_Click()
    Dim lngCount As Long
    Dim sFileName As String
    sFileName = txtDriveLetter.Text & ":\" ' Can be up to 32,767 chars
    lstStuff.Clear
    lngCount = 0
    FindMyFiles sFileName, lngCount
End Sub

Private Sub FindMyFiles(Path As String, lngFileCount As Long)
    Dim k As Long
    Dim NumberDirectories As Long
    Dim strListDirectoryNames() As String
    ' The following can be Static or Private
    Dim Filename As String
    Dim hSearch As Long
    Dim WFD As WIN32_FIND_DATA
  
    NumberDirectories = -1
    hSearch = FindFirstFileW(StrPtr(Path & "*"), VarPtr(WFD))
    If hSearch <> INVALID_HANDLE_VALUE Then
        With txtProcessed
            Do
                DoEvents
                Filename = RemoveNulls((WFD.cFileName))
                If (Filename <> ".") And (Filename <> "..") Then
                    If (WFD.dwFileAttributes And FILE_ATTRIBUTE_DIRECTORY) = 0 Then
                        lngFileCount = lngFileCount + 1
                        .Text = FormatNumber(lngFileCount, NumDigitsAfterDecimal:=0, GroupDigits:=vbTrue)
'                        With lstStuff
'                            .AddItem lngFileCount & ": " & Path & Filename
'                            k = SendMessage(.hwnd, LB_GETCOUNT, ByVal 0&, ByVal 0&)
'                            SendMessage .hwnd, LB_SETTOPINDEX, k - 1, ByVal 0&
'                        End With
                    Else
                        NumberDirectories = NumberDirectories + 1
                        ReDim Preserve strListDirectoryNames(NumberDirectories)
                        strListDirectoryNames(NumberDirectories) = Filename
                    End If
                End If
            Loop While FindNextFileW(hSearch, VarPtr(WFD)) <> 0
        End With
        k = FindClose(hSearch)
    End If

    If NumberDirectories <> -1 Then
        For k = 0 To NumberDirectories
            FindMyFiles Path & strListDirectoryNames(k) & "\", lngFileCount
        Next k
    End If
End Sub

Private Function RemoveNulls(OriginalString As String) As String
    Dim pos As Long
    pos = InStr(OriginalString, Chr$(0))
    If pos > 1 Then
        RemoveNulls = Mid$(OriginalString, 1, pos - 1)
    Else
        RemoveNulls = OriginalString
    End If
End Function

