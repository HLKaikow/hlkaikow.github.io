Option Explicit On 
Option Strict On
Option Compare Text
Imports System.Runtime.InteropServices
Imports System.IO
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Public WithEvents txtDriveLetter As System.Windows.Forms.TextBox
    Public WithEvents txtProcessed As System.Windows.Forms.TextBox
    Public WithEvents lstStuff As System.Windows.Forms.ListBox
    Public WithEvents btnRunMe As System.Windows.Forms.Button
    Public WithEvents lblDriveLetter As System.Windows.Forms.Label
    Public WithEvents lblProcessed As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtDriveLetter = New System.Windows.Forms.TextBox
        Me.txtProcessed = New System.Windows.Forms.TextBox
        Me.lstStuff = New System.Windows.Forms.ListBox
        Me.btnRunMe = New System.Windows.Forms.Button
        Me.lblDriveLetter = New System.Windows.Forms.Label
        Me.lblProcessed = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'txtDriveLetter
        '
        Me.txtDriveLetter.AcceptsReturn = True
        Me.txtDriveLetter.AutoSize = False
        Me.txtDriveLetter.BackColor = System.Drawing.SystemColors.Window
        Me.txtDriveLetter.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDriveLetter.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDriveLetter.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDriveLetter.Location = New System.Drawing.Point(136, 8)
        Me.txtDriveLetter.MaxLength = 0
        Me.txtDriveLetter.Name = "txtDriveLetter"
        Me.txtDriveLetter.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDriveLetter.Size = New System.Drawing.Size(97, 19)
        Me.txtDriveLetter.TabIndex = 10
        Me.txtDriveLetter.Text = ""
        '
        'txtProcessed
        '
        Me.txtProcessed.AcceptsReturn = True
        Me.txtProcessed.AutoSize = False
        Me.txtProcessed.BackColor = System.Drawing.SystemColors.Window
        Me.txtProcessed.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProcessed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProcessed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtProcessed.Location = New System.Drawing.Point(384, 8)
        Me.txtProcessed.MaxLength = 0
        Me.txtProcessed.Name = "txtProcessed"
        Me.txtProcessed.ReadOnly = True
        Me.txtProcessed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtProcessed.Size = New System.Drawing.Size(137, 19)
        Me.txtProcessed.TabIndex = 9
        Me.txtProcessed.Text = ""
        '
        'lstStuff
        '
        Me.lstStuff.BackColor = System.Drawing.SystemColors.Window
        Me.lstStuff.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstStuff.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstStuff.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstStuff.HorizontalScrollbar = True
        Me.lstStuff.ItemHeight = 14
        Me.lstStuff.Location = New System.Drawing.Point(8, 32)
        Me.lstStuff.Name = "lstStuff"
        Me.lstStuff.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstStuff.Size = New System.Drawing.Size(793, 480)
        Me.lstStuff.TabIndex = 7
        '
        'btnRunMe
        '
        Me.btnRunMe.BackColor = System.Drawing.SystemColors.Control
        Me.btnRunMe.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnRunMe.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRunMe.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnRunMe.Location = New System.Drawing.Point(720, 8)
        Me.btnRunMe.Name = "btnRunMe"
        Me.btnRunMe.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnRunMe.Size = New System.Drawing.Size(81, 21)
        Me.btnRunMe.TabIndex = 6
        Me.btnRunMe.Text = "Run Me!"
        '
        'lblDriveLetter
        '
        Me.lblDriveLetter.BackColor = System.Drawing.SystemColors.Control
        Me.lblDriveLetter.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDriveLetter.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDriveLetter.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDriveLetter.Location = New System.Drawing.Point(8, 8)
        Me.lblDriveLetter.Name = "lblDriveLetter"
        Me.lblDriveLetter.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDriveLetter.Size = New System.Drawing.Size(121, 17)
        Me.lblDriveLetter.TabIndex = 11
        Me.lblDriveLetter.Text = "Drive Letter?"
        '
        'lblProcessed
        '
        Me.lblProcessed.BackColor = System.Drawing.SystemColors.Control
        Me.lblProcessed.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblProcessed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProcessed.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblProcessed.Location = New System.Drawing.Point(296, 16)
        Me.lblProcessed.Name = "lblProcessed"
        Me.lblProcessed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblProcessed.Size = New System.Drawing.Size(73, 17)
        Me.lblProcessed.TabIndex = 8
        Me.lblProcessed.Text = "Processing"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(808, 517)
        Me.Controls.Add(Me.txtDriveLetter)
        Me.Controls.Add(Me.txtProcessed)
        Me.Controls.Add(Me.lstStuff)
        Me.Controls.Add(Me.btnRunMe)
        Me.Controls.Add(Me.lblDriveLetter)
        Me.Controls.Add(Me.lblProcessed)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region
    <DllImport("kernel32", CharSet:=CharSet.Unicode, SetLastError:=False)> _
    Private Shared Function FindClose _
        (ByVal hFindFile As Integer) As Integer
    End Function
    <DllImport("kernel32", CharSet:=CharSet.Unicode, SetLastError:=True)> _
    Private Shared Function FindFirstFileW _
        (ByVal lpFileName As String, ByRef lpFindFileData As WIN32_FIND_DATA) As Integer
    End Function

    <DllImport("kernel32", CharSet:=CharSet.Unicode, SetLastError:=True)> _
    Private Shared Function FindNextFileW _
        (ByVal hFindFile As Integer, ByRef lpFindFileData As WIN32_FIND_DATA) As Integer
    End Function

    <DllImport("user32", CharSet:=CharSet.Unicode, SetLastError:=False)> _
    Private Shared Function SendMessage _
        (ByVal hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByRef lParam As Integer) As Integer
    End Function

    Private Structure FILETIME
        Dim dwLowDateTime As Integer
        Dim dwHighDateTime As Integer
    End Structure

    Private Const ALTERNATE As Integer = 14
    Private Const FILE_ATTRIBUTE_DIRECTORY As Integer = &H10S
    Private Const INVALID_HANDLE_VALUE As Integer = -1
    Private Const MAX_PATH As Integer = 260
    Private Const LB_GETCOUNT As Integer = &H18BS
    Private Const LB_SETTOPINDEX As Integer = &H197S

    <Serializable(), StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)> _
    Private Structure WIN32_FIND_DATA
        Dim dwFileAttributes As FileAttributes
        Dim ftCreationTime As FILETIME
        Dim ftLastAccessTime As FILETIME
        Dim ftLastWriteTime As FILETIME
        Dim nFileSizeHigh As Integer
        Dim nFileSizeLow As Integer
        Dim dwReserved0 As Integer
        Dim dwReserved1 As Integer
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=MAX_PATH)> _
          Dim cFileName As String
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=ALTERNATE)> _
            Dim cAlternate As String
    End Structure

    Private Sub btnRunMe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRunMe.Click
        Dim lngCount As Integer
        Dim sFileName As String
        sFileName = txtDriveLetter.Text & ":\" ' Can be up to 32,767 chars
        lstStuff.Items.Clear()
        lngCount = 0
        FindMyFiles(sFileName, lngCount)
    End Sub
    Private Sub FindMyFiles(ByRef Path As String, ByRef lngFileCount As Integer)
        Dim k As Integer
        Dim NumberDirectories As Integer
        Dim strListDirectoryNames() As String
        ' The following can be Static or Private
        Dim Filename As String
        Dim hSearch As Integer
        Dim WFD As WIN32_FIND_DATA

        NumberDirectories = -1
        hSearch = FindFirstFileW(Path & "*", WFD)
        If hSearch <> INVALID_HANDLE_VALUE Then
            With txtProcessed
                Do
                    System.Windows.Forms.Application.DoEvents()
                    Filename = RemoveNulls(WFD.cFileName)
                    If (Filename <> ".") And (Filename <> "..") Then
                        If (WFD.dwFileAttributes And FILE_ATTRIBUTE_DIRECTORY) = 0 Then
                            lngFileCount = lngFileCount + 1
                            .Text = FormatNumber(lngFileCount, 0, , , TriState.True)
                            'With lstStuff
                            '    .Items.Add(lngFileCount & ": " & Path & Filename)
                            '    k = SendMessage(.Handle.ToInt32, LB_GETCOUNT, 0, 0)
                            '    SendMessage(.Handle.ToInt32, LB_SETTOPINDEX, k - 1, 0)
                            'End With
                        Else
                            NumberDirectories = NumberDirectories + 1
                            ReDim Preserve strListDirectoryNames(NumberDirectories)
                            strListDirectoryNames(NumberDirectories) = Filename
                        End If
                    End If
                Loop While FindNextFileW(hSearch, WFD) <> 0
            End With
            k = FindClose(hSearch)
        End If

        If NumberDirectories <> -1 Then
            For k = 0 To NumberDirectories
                FindMyFiles(Path & strListDirectoryNames(k) & "\", lngFileCount)
            Next k
        End If
    End Sub

    Private Function RemoveNulls(ByRef OriginalString As String) As String
        Dim pos As Integer
        pos = InStr(OriginalString, Chr(0))
        If pos > 1 Then
            RemoveNulls = Mid(OriginalString, 1, pos - 1)
        Else
            RemoveNulls = OriginalString
        End If
    End Function
End Class
