VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmTIFFTagDump 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "TIFF Tag Dump"
   ClientHeight    =   4695
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6750
   ClipControls    =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4695
   ScaleWidth      =   6750
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton btnExit 
      Caption         =   "Exit"
      Height          =   315
      Left            =   2160
      TabIndex        =   8
      Top             =   4080
      Width           =   1275
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   3600
      Top             =   4200
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton btnBrowse 
      Caption         =   "Browse"
      Height          =   315
      Left            =   360
      TabIndex        =   3
      Top             =   4080
      Width           =   1275
   End
   Begin VB.CommandButton cmdDump 
      Caption         =   "Dump Tags"
      Height          =   465
      Left            =   4800
      TabIndex        =   2
      Top             =   3990
      Width           =   1815
   End
   Begin VB.Frame fraTags 
      Caption         =   "Tiff Tags:"
      Height          =   2895
      Left            =   195
      TabIndex        =   1
      Top             =   930
      Width           =   6375
      Begin VB.ListBox lstTags 
         Height          =   2400
         Left            =   135
         TabIndex        =   5
         Top             =   315
         Width           =   6105
      End
   End
   Begin VB.Label lblNumberTags 
      Height          =   195
      Left            =   1800
      TabIndex        =   7
      Top             =   600
      Width           =   2655
   End
   Begin VB.Label lblTIFFTags 
      Caption         =   "Number of TIFF tags:"
      Height          =   195
      Left            =   195
      TabIndex        =   6
      Top             =   600
      Width           =   1575
   End
   Begin VB.Label lblPath 
      AutoSize        =   -1  'True
      Height          =   195
      Left            =   1080
      TabIndex        =   4
      Top             =   100
      Width           =   5460
      WordWrap        =   -1  'True
   End
   Begin VB.Label lblFileName 
      AutoSize        =   -1  'True
      Caption         =   "File Name:"
      Height          =   195
      Left            =   195
      TabIndex        =   0
      Top             =   100
      Width           =   750
   End
End
Attribute VB_Name = "frmTIFFTagDump"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'=============================================================
' frmTIFFTagDump
'-------------------------------------------------------------
' Purpose: List tags in a TIFF file
' Author : Howard Kaikow
' Email: kaikow@standards.com
' Notes : As I recall, this code was tested against only 1 file.
'-------------------------------------------------------------
' Parameters
'-----------
'
'-------------------------------------------------------------
' Returns:
'-------------------------------------------------------------
' Revision History
'-------------------------------------------------------------
' 9 September 1998 (Ron Abbe): Original code.
' 24-25 December 2000 (Howard Kaikow): Added Browse capability
'         and a count of the number of TIFF tags.
' 31 July 2001(Howard Kaikow): Added identifying comments and
'         minor code changes.
' 1 August 2001(Howard Kaikow): Minor code changes.
'=============================================================
Option Explicit
    
    Dim strFileName   As String

    Private Type Header
        TiffID   As String * 4
        FirstIFD As Long
    End Type
    
    Private Type TiffIFDEntry
        TagID       As Integer
        FieldType   As Integer
        Count       As Long
        ValueOffset As Long
    End Type

Private Sub btnBrowse_Click()
    CommonDialog1.CancelError = True
    On Error GoTo DoNothing
    CommonDialog1.ShowOpen
    btnBrowse.Visible = False
DoNothing:
    Select Case Err.Number
        Case 0
        Case cdlCancel
            SayByeBye
        Case Else
            MsgBox Err.Description & vbCr & Err.Number
            SayByeBye
    End Select
    ' Get the file name of the tiff file to open.
    lblNumberTags.Caption = ""
    strFileName = CommonDialog1.FileName
    lblPath.Caption = strFileName
    lstTags.Clear
End Sub

Private Sub btnExit_Click()
    SayByeBye
End Sub

Private Sub cmdDump_Click()
    Call DumpTags
    btnBrowse.Visible = True
End Sub

Private Sub DumpTags()
    Dim intCount        As Integer
    Dim intIfdEntries   As Integer
    Dim intInFile       As Integer
    Dim uHeader         As Header
    Dim uIFD            As TiffIFDEntry
    
    ' Get the next available file handle.
    intInFile = FreeFile
    
    ' Open the TIFF file for binary access.
    Open strFileName For Binary As #intInFile
    
    ' Read in the tiff header.
    Get #intInFile, , uHeader
    
    ' Seek to the start of the ifd.
    Seek #intInFile, uHeader.FirstIFD + 1
    
    ' Get the number of entries in this ifd.
    Get #intInFile, , intIfdEntries
    lblNumberTags.Caption = intIfdEntries

    ' Loop through all of the tiff ifd entries.
    For intCount = 1 To intIfdEntries
        ' Get the IFD entry.
        Get #intInFile, , uIFD
    
        ' Add the tag to the list.
        With uIFD
            lstTags.AddItem Trim$(CStr(.TagID)) & vbTab & CStr(.FieldType) & vbTab & _
                CStr(.Count) & vbTab & CStr(.ValueOffset)
        End With
    Next    ' intCount
    
    ' Close the tiff file.
    Close #intInFile
End Sub

Private Sub SayByeBye()
    Unload Me
    End
End Sub
