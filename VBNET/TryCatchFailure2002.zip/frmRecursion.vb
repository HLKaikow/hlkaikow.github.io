Public Class frmRecursion
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblRecursion As System.Windows.Forms.Label
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblRecursion = New System.Windows.Forms.Label
        Me.btnStart = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'lblRecursion
        '
        Me.lblRecursion.Location = New System.Drawing.Point(16, 16)
        Me.lblRecursion.Name = "lblRecursion"
        Me.lblRecursion.Size = New System.Drawing.Size(208, 80)
        Me.lblRecursion.TabIndex = 0
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(168, 144)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.TabIndex = 1
        Me.btnStart.Text = "Push me!"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(168, 200)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        '
        'frmRecursion
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.lblRecursion)
        Me.Name = "frmRecursion"
        Me.Text = "Recursion 101"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private CountMe As Integer
    Private Const min As Integer = 0
    Private Const max As Integer = 999
    Private Const maxPlus1 As Integer = max + 1

    Private GetRandom As New Random
    'Private x As Double
    'Private MyLabel As Label

    ' Neither the  Try/Catch in btnStart_Click, or in TestRecursion, will detect a stack overflow
    ' error if ANY of the code blocks identified as L or Bn are uncommented, where "n" is a number
    ' from 1 to the number of code blocks identified as failing that use Rnd or Random.

    ' If code block L is not uncommented, then Try/Catch will detect a stack overflow error if any
    ' of the code blocks identified as Gm are uncommented, where "m" is a number from 1 to the
    ' number of code blocks identified as OK that use Random.

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        CountMe = 0
        'MyLabel = Me.lblRecursion

        Try
            TestRecursion()
        Catch
            MsgBox(Err.Number & ": " & Err.Description, , _
                "Detected: Not in TestRecursion" & CountMe.ToString)
            lblRecursion.Refresh()
        End Try
    End Sub

    Private Sub TestRecursion()
        Dim x As Double
        'Static x As Double
        Try
            ''''' Start Code Block B1 ''''''''''''''
            ' Fails: Causes stack overflow to not be detected by Try/Catch
            'x = Int((max - min + 1) * Rnd() + min)
            ''''' End Code Block B1 ''''''''''''''

            ''''' Start Code Block B2 ''''''''''''''
            ' Fails: Causes stack overflow to not be detected by Try/Catch
            'x = (max - min + 1) * Rnd() + min
            'x = Int(x)
            ''''' End Code Block B2 ''''''''''''''

            ''''' Start Code Block B3 ''''''''''''''
            ' Fails: Causes stack overflow to not be detected by Try/Catch
            'x = Int((max - min + 1) * GetRandom.NextDouble() + min)
            ''''' End Code Block B3 ''''''''''''''

            ''''' Start Code Block G1 ''''''''''''''
            ' OK: Stack overlow is detected by Try/Catch
            'x = (max - min + 1) * GetRandom.NextDouble() + min
            'x = Int(x)
            ''''' End Code Block G1 ''''''''''''''

            ''''' Start Code Block G2 ''''''''''''''
            ' OK: Stack overlow is detected by Try/Catch
            'x = GetRandom.Next(min, maxPlus1)
            ''''' End Code Block G2 ''''''''''''''

            ''''' Start Code Block G3 ''''''''''''''
            ' OK: Stack overlow is detected by Try/Catch
            'x = Int(GetRandom.Next(min, maxPlus1))
            ''''' End Code Block G3 ''''''''''''''

            ''''' Start Code Block G4 ''''''''''''''
            ' OK: Stack overlow is detected by Try/Catch
            'x = 1
            ''''' End Code Block G4 ''''''''''''''

            CountMe = CountMe + 1

            ''''' Start Code Block L ''''''''''''''
            ' Fails: Causes stack overflow to not be detected by Try/Catch
            '''''''With MyLabel
            'With lblRecursion
            '    .Text = CountMe.ToString
            '    .Refresh()
            'End With
            ''''' End Code Block L ''''''''''''''
            TestRecursion()
        Catch
            MsgBox(Err.Number & ": " & Err.Description, , _
                "Detected by Try/Catch: In TestRecursion" & CountMe.ToString)
            lblRecursion.Refresh()
        End Try
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
End Class
